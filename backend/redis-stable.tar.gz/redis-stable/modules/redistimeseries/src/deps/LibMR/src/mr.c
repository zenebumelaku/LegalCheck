/*
 * Copyright (c) 2006-Present, Redis Ltd.
 * All rights reserved.
 *
 * Licensed under your choice of (a) the Redis Source Available License 2.0
 * (RSALv2); or (b) the Server Side Public License v1 (SSPLv1); or (c) the
 * GNU Affero General Public License v3 (AGPLv3).
 */

#include "redismodule.h"

#include "common.h"
#include "mr.h"
#include "utils/arr_rm_alloc.h"
#include "utils/dict.h"
#include "mr_memory.h"
#include "event_loop.h"
#include "cluster.h"
#include "record.h"
#include "utils/thpool.h"
#include "utils/adlist.h"
#include "utils/buffer.h"

#include <pthread.h>
#include <hiredis.h>
#ifndef EXECUTION_DEFAULT_MAX_IDLE_MS
#define EXECUTION_DEFAULT_MAX_IDLE_MS 5000
#endif

#define ID_LEN REDISMODULE_NODE_ID_LEN + sizeof(size_t)
#define STR_ID_LEN  REDISMODULE_NODE_ID_LEN + 13

MR_RedisVersion MR_currVersion;
int MR_RlecMajorVersion;
int MR_RlecMinorVersion;
int MR_RlecPatchVersion;
int MR_RlecBuild;
int MR_RlecVersionPresent;

RedisModuleCtx* mr_staticCtx;

/* Remote functions ids. NOTE: The actual values are set during MR_Init() and they start at 1! (0 is MR_NetworkTest) */
functionId NEW_EXECUTION_RECEIVED_FUNCTION_ID = 0;
functionId ACK_EXECUTION_FUNCTION_ID = 0;
functionId INVOKE_EXECUTION_FUNCTION_ID = 0;
functionId PASS_RECORD_FUNCTION_ID = 0;
functionId NOTIFY_DONE_FUNCTION_ID = 0;
functionId NOTIFY_STEP_DONE_FUNCTION_ID = 0;
functionId DROP_EXECUTION_FUNCTION_ID = 0;
functionId REMOTE_TASK_FUNCTION_ID = 0;
functionId REMOTE_TASK_DONE_FUNCTION_ID = 0;

typedef struct RemoteFunctionDef {
    functionId* funcIdPointer;
    MR_ClusterMessageReceiver functionPointer;
}RemoteFunctionDef;

typedef struct Step Step;

// Returns true if the callback disposed (freed) the execution, in which case the
// caller (MR_ExecutionMain) must not touch it afterwards. Returns false otherwise,
// so the caller keeps draining the execution's task queue.
typedef bool (*ExecutionTaskCallback)(Execution* e, void* pd);

/* functions declarations */
static void MR_ExecutionAddTask(Execution* e, ExecutionTaskCallback callback, void* pd);
static bool MR_RunExecution(Execution* e, void* pd);
static Record* MR_RunStep(Execution* e, Step* s);
void MR_FreeExecution(Execution* e);

/* Remote functions declaration */
static void MR_NewExecutionReceived(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_AckExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_InvokeExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_PassRecord(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_NotifyDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_NotifyStepDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_DropExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_RemoteTask(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);
static void MR_RemoteTaskDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload);

/* Remote functions array */
static RemoteFunctionDef remoteFunctions[] = {
        {
                .funcIdPointer = &NEW_EXECUTION_RECEIVED_FUNCTION_ID,
                .functionPointer = MR_NewExecutionReceived,
        },
        {
                .funcIdPointer = &ACK_EXECUTION_FUNCTION_ID,
                .functionPointer = MR_AckExecution,
        },
        {
                .funcIdPointer = &INVOKE_EXECUTION_FUNCTION_ID,
                .functionPointer = MR_InvokeExecution,
        },
        {
                .funcIdPointer = &PASS_RECORD_FUNCTION_ID,
                .functionPointer = MR_PassRecord,
        },
        {
                .funcIdPointer = &NOTIFY_DONE_FUNCTION_ID,
                .functionPointer = MR_NotifyDone,
        },
        {
                .funcIdPointer = &NOTIFY_STEP_DONE_FUNCTION_ID,
                .functionPointer = MR_NotifyStepDone,
        },
        {
                .funcIdPointer = &DROP_EXECUTION_FUNCTION_ID,
                .functionPointer = MR_DropExecution,
        },
        {
                .funcIdPointer = &REMOTE_TASK_FUNCTION_ID,
                .functionPointer = MR_RemoteTask,
        },
        {
                .funcIdPointer = &REMOTE_TASK_DONE_FUNCTION_ID,
                .functionPointer = MR_RemoteTaskDone,
        },
};

typedef struct MRStats {
    size_t nMissedExecutions;
    size_t nMaxIdleReached;
}MRStats;

struct StepDefinition;

struct MRCtx {
    size_t lastExecutionId;

    /* protected by the event loop */
    mr_dict* executionsDict;

    /* protected by the event loop */
    mr_dict* remoteDict;

    /* should be initialized at start and then read only */
    ARR(MRObjectType*) objectTypesDict;

    /* Steps dictionaries */
    mr_dict* readerDict;
    mr_dict* mappersDict;
    mr_dict* remoteTasksDict;
    mr_dict* filtersDict;
    mr_dict* accumulatorsDict;
    mr_dict* internalCommandsDict;

    mr_threadpool executionsThreadPool;

    MRStats stats;
}mrCtx;

static uint64_t idHashFunction(const void *key){
    return mr_dictGenHashFunction(key, ID_LEN);
}

static int idKeyCompare(void *privdata, const void *key1, const void *key2){
    return memcmp(key1, key2, ID_LEN) == 0;
}

static void idKeyDestructor(void *privdata, void *key){
    MR_FREE(key);
}

static void* idKeyDup(void *privdata, const void *key){
    char* ret = MR_ALLOC(ID_LEN);
    memcpy(ret, key , ID_LEN);
    return ret;
}

mr_dictType dictTypeHeapIds = {
        .hashFunction = idHashFunction,
        .keyDup = idKeyDup,
        .valDup = NULL,
        .keyCompare = idKeyCompare,
        .keyDestructor = idKeyDestructor,
        .valDestructor = NULL,
};

typedef enum StepType {
    StepType_Reader,
    StepType_Mapper,
    StepType_Filter,
    StepType_Accumulator,
    StepType_Reshuffle,
    StepType_Collect,
    StepType_InternalCommand,
}StepType;

typedef struct StepDefinition {
    char* name;
    MRObjectType* type;
    void* callback;
}StepDefinition;

typedef struct ReadStep {
    ExecutionReader readCallback;
}ReadStep;

typedef struct MapStep {
    ExecutionMapper mapCallback;
}MapStep;

typedef struct AccumulateStep {
    ExecutionAccumulator accumulateCallback;
    Record* accumulator;
}AccumulateStep;

typedef struct InternalCommandStep {
    InternalCommand command;
    InternalCommandReplyParser replyParser;
    redisReply *reply;  // to be parsed by the replyParser
    size_t nDone;
}InternalCommandStep;

typedef struct FilterStep {
    ExecutionFilter filterCallback;
}FilterStep;

typedef struct CollectStep {
    ARR(Record*) collectedRecords;
    size_t nDone;
}CollectStep;

typedef struct ReshuffleStep {
    ARR(Record*) pendingRecords;
    size_t nDone;
    int sentDoneMsg;
}ReshuffleStep;

typedef struct ExecutionBuilderStep {
    void* args;
    MRObjectType* argsType;
    char* name;
    StepType type;
}ExecutionBuilderStep;

#define StepFlag_Done   (1 << 0)

struct Step {
    int flags;
    ExecutionBuilderStep bStep;
    union {
        MapStep map;
        FilterStep filter;
        ReadStep read;
        CollectStep collect;
        ReshuffleStep reshuffle;
        AccumulateStep accumulate;
        InternalCommandStep internalCommand;
    };
    size_t index;
    struct Step* child;
};

struct ExecutionBuilder {
    ARR(ExecutionBuilderStep) steps;
};

#define ExecutionFlag_Initiator (1 << 0)
#define ExecutionFlag_Local     (1 << 1)

typedef struct ExecutionCallbackData {
    void* pd;
    ExecutionCallback callback;
}ExecutionCallbackData;

typedef struct ExecutionCallbacks {
    ExecutionCallbackData done;
    ExecutionCallbackData resume;
    ExecutionCallbackData hold;
}ExecutionCallbacks;

struct Execution {
    int flags;
    size_t refCount;
    char id[ID_LEN];
    char idStr[STR_ID_LEN];
    ARR(Step) steps;
    pthread_mutex_t eLock; /* lock for critical sections of the execution */
    mr_list* tasks;

    size_t nReceived;
    size_t nCompleted;
    ARR(Record*) results;
    ARR(Record*) errors;

    ExecutionCallbacks callbacks;
    MR_LoopTaskCtx* timeoutTask;
    size_t timeoutMS;
};

struct ExecutionCtx {
    Execution* e;
    Record* err;
};

typedef struct mr_BufferWriter WriteSerializationCtx;
typedef struct mr_BufferReader ReaderSerializationCtx;

typedef struct ExecutionTask {
    ExecutionTaskCallback callback;
    void* pd;
}ExecutionTask;

typedef enum MRErrorType {
    MRErrorType_Static, MRErrorType_Dynamic,
}MRErrorType;

struct MRError {
    MRErrorType type;
    char* msg;
};

MRError UINITIALIZED_CLUSTER_ERROR = {.type = MRErrorType_Static, .msg = "uninitialized cluster"};
MRError BUFFER_READ_ERROR = {.type = MRErrorType_Static, .msg = "failed reading data from buffer"};

static StepDefinition* MR_GetStepDefinition(StepType type, const char* name) {
    switch (type) {
    case StepType_Mapper:
        return mr_dictFetchValue(mrCtx.mappersDict, name);
    case StepType_Filter:
        return mr_dictFetchValue(mrCtx.filtersDict, name);
    case StepType_Reader:
        return mr_dictFetchValue(mrCtx.readerDict, name);
    case StepType_Accumulator:
        return mr_dictFetchValue(mrCtx.accumulatorsDict, name);
    case StepType_InternalCommand:
        return  mr_dictFetchValue(mrCtx.internalCommandsDict, name);
    }

    return NULL;
}

ExecutionBuilder* MR_CreateEmptyExecutionBuilder() {
    ExecutionBuilder* builder = MR_ALLOC(sizeof(*builder));
    builder->steps = array_new(ExecutionBuilderStep, 10);
    return builder;
}

ExecutionBuilder* MR_CreateExecutionBuilder(const char* readerName, void* args) {
    ExecutionBuilder* builder = MR_CreateEmptyExecutionBuilder();

    StepDefinition* sd = mr_dictFetchValue(mrCtx.readerDict, readerName);
    RedisModule_Assert(sd);
    ExecutionBuilderStep s = {
            .args = args,
            .argsType = sd->type,
            .name = MR_STRDUP(readerName),
            .type = StepType_Reader,
    };
    builder->steps = array_append(builder->steps, s);

    return builder;
}

void MR_ExecutionBuilderCollect(ExecutionBuilder* builder) {
    RedisModule_Assert(array_len(builder->steps) > 0);
    RedisModule_Assert(builder->steps[0].type != StepType_InternalCommand);
    ExecutionBuilderStep s = {
            .args = NULL,
            .argsType = NULL,
            .name = NULL,
            .type = StepType_Collect,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_ExecutionBuilderMap(ExecutionBuilder* builder, const char* name, void* args) {
    RedisModule_Assert(array_len(builder->steps) > 0);
    RedisModule_Assert(builder->steps[0].type != StepType_InternalCommand);
    StepDefinition* sd = mr_dictFetchValue(mrCtx.mappersDict, name);
    RedisModule_Assert(sd);
    ExecutionBuilderStep s = {
            .args = args,
            .argsType = sd->type,
            .name = MR_STRDUP(name),
            .type = StepType_Mapper,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_ExecutionBuilderFilter(ExecutionBuilder* builder, const char* name, void* args) {
    RedisModule_Assert(array_len(builder->steps) > 0);
    RedisModule_Assert(builder->steps[0].type != StepType_InternalCommand);
    StepDefinition* sd = mr_dictFetchValue(mrCtx.filtersDict, name);
    RedisModule_Assert(sd);
    ExecutionBuilderStep s = {
            .args = args,
            .argsType = sd->type,
            .name = MR_STRDUP(name),
            .type = StepType_Filter,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_ExecutionBuilderBuildAccumulate(ExecutionBuilder* builder, const char* name, void* args) {
    RedisModule_Assert(array_len(builder->steps) > 0);
    RedisModule_Assert(builder->steps[0].type != StepType_InternalCommand);
    StepDefinition* sd = mr_dictFetchValue(mrCtx.accumulatorsDict, name);
    RedisModule_Assert(sd);
    ExecutionBuilderStep s = {
            .args = args,
            .argsType = sd->type,
            .name = MR_STRDUP(name),
            .type = StepType_Accumulator,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_ExecutionBuilderReshuffle(ExecutionBuilder* builder) {
    RedisModule_Assert(array_len(builder->steps) > 0);
    RedisModule_Assert(builder->steps[0].type != StepType_InternalCommand);
    ExecutionBuilderStep s = (ExecutionBuilderStep){
            .args = NULL,
            .argsType = NULL,
            .name = NULL,
            .type = StepType_Reshuffle,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_ExecutionBuilderInternalCommand(ExecutionBuilder* builder, const char *name, void *args) {
    // We allow either all steps being internal commands, or none of them
    RedisModule_Assert(array_len(builder->steps) == 0 || builder->steps[0].type == StepType_InternalCommand);
    StepDefinition* sd = MR_GetStepDefinition(StepType_InternalCommand, name);
    RedisModule_Assert(sd);
    ExecutionBuilderStep s = {
            .args = args,
            .argsType = sd->type,
            .name = MR_STRDUP(sd->name),
            .type = StepType_InternalCommand,
    };
    builder->steps = array_append(builder->steps, s);
}

void MR_FreeExecutionBuilder(ExecutionBuilder* builder) {
    for (size_t i = 0 ; i < array_len(builder->steps) ; ++i) {
        ExecutionBuilderStep* s = builder->steps + i;
        if (s->name) {
            MR_FREE(s->name);
        }
        if (s->args) {
            s->argsType->free(s->args);
        }
    }
    array_free(builder->steps);
    MR_FREE(builder);
}

static void SetId(char* idBuf, char* idBufStr, size_t id){
    char nonClusterId[REDISMODULE_NODE_ID_LEN] = {0};
    const char* shardId;
    if(MR_ClusterIsClusterMode()){
        shardId = MR_ClusterGetMyId();
    }else{
        memset(nonClusterId, '0', REDISMODULE_NODE_ID_LEN);
        shardId = nonClusterId;
    }
    memcpy(idBuf, shardId, REDISMODULE_NODE_ID_LEN);
    memcpy(idBuf + REDISMODULE_NODE_ID_LEN, &id, sizeof(size_t));
    snprintf(idBufStr, STR_ID_LEN, "%.*s-%lld", REDISMODULE_NODE_ID_LEN, idBuf, *(long long*)&idBuf[REDISMODULE_NODE_ID_LEN]);
}

static void MR_InitializeFromStepDef(Step*s, StepDefinition* sd) {
    switch (s->bStep.type) {
    case StepType_Reader:
        s->read.readCallback = sd->callback;
        break;
    case StepType_Mapper:
        s->map.mapCallback = sd->callback;
        break;
    case StepType_Filter:
        s->filter.filterCallback = sd->callback;
        break;
    case StepType_Reshuffle:
        s->reshuffle.pendingRecords = array_new(Record*, 20);
        s->reshuffle.nDone = 0;
        s->reshuffle.sentDoneMsg = 0;
        break;
    case StepType_Collect:
        s->collect.collectedRecords = array_new(Record*, 20);
        s->collect.nDone = 0;
        break;
    case StepType_Accumulator:
        s->accumulate.accumulateCallback = sd->callback;
        s->accumulate.accumulator = NULL;
        break;
    case StepType_InternalCommand:
    {
        InternalCommandCallbacks *callbacks = sd->callback;
        s->internalCommand.command = callbacks->command;
        s->internalCommand.replyParser = callbacks->replyParser;
        s->internalCommand.reply = NULL;
        s->internalCommand.nDone = 0;
        break;
    }
    default:
        RedisModule_Assert(false);
    }
}

static void MR_CreateExecutionStep(Step*s, ExecutionBuilderStep* builderStep) {
    s->bStep.type = builderStep->type;
    s->bStep.argsType = builderStep->argsType;
    s->bStep.name = builderStep->name? MR_STRDUP(builderStep->name) : NULL;
    if (builderStep->args) {
        s->bStep.args = s->bStep.argsType->dup(builderStep->args);
    } else {
        s->bStep.args = NULL;
    }

    StepDefinition* sDef = MR_GetStepDefinition(s->bStep.type, s->bStep.name);
    MR_InitializeFromStepDef(s, sDef);
}

static Execution* MR_ExecutionAlloc() {
    Execution* e = MR_ALLOC(sizeof(*e));
    e->refCount = 1;
    e->steps = array_new(Step, 10);
    pthread_mutex_init(&e->eLock, NULL);
    e->tasks = mr_listCreate();
    mr_listSetFreeMethod(e->tasks, MR_FREE);
    e->nReceived = 0;
    e->nCompleted = 0;
    e->results = array_new(Record*, 10);
    e->errors = array_new(Record*, 10);
    e->callbacks = (ExecutionCallbacks){
            .done = {.pd = NULL, .callback = NULL},
            .resume = {.pd = NULL, .callback = NULL},
            .hold = {.pd = NULL, .callback = NULL},
    };
    e->timeoutTask = NULL;
    e->timeoutMS = EXECUTION_DEFAULT_MAX_IDLE_MS;
    e->flags = 0;
    return e;
}

Execution* MR_CreateExecution(ExecutionBuilder* builder, MRError** err) {
    if (!MR_IsClusterInitialize()) {
        *err = &UINITIALIZED_CLUSTER_ERROR;
    }

    Execution* e = MR_ExecutionAlloc();

    /* Set execution id */
    size_t id = __atomic_add_fetch(&mrCtx.lastExecutionId, 1, __ATOMIC_RELAXED);
    SetId(e->id, e->idStr, id);

    /* Copy steps array. */
    Step* child = NULL;
    for (size_t i = 0 ; i < array_len(builder->steps) ; ++i) {
        ExecutionBuilderStep* builderStep = builder->steps + i;
        Step s;
        MR_CreateExecutionStep(&s, builderStep);
        s.index = array_len(e->steps);
        s.flags = 0;
        s.child = child;
        e->steps = array_append(e->steps, s);
        child = e->steps + array_len(e->steps) - 1;
    }

    e->flags |= ExecutionFlag_Initiator;
    if (!MR_ClusterIsClusterMode()) {
        e->flags |= ExecutionFlag_Local;
    }

    return e;
}

Execution *MR_GetExecution(const char *message, size_t messageLength) {
    mr_Buffer buff = (mr_Buffer){
        .buff = (char*)message,
        .size = messageLength,
        .cap = messageLength,
    };
    mr_BufferReader reader;
    mr_BufferReaderInit(&reader, &buff);
    size_t executionIdLen;
    const char* executionId = mr_BufferReaderReadBuff(&reader, &executionIdLen, NULL);
    RedisModule_Assert(executionIdLen == ID_LEN);

    return mr_dictFetchValue(mrCtx.executionsDict, executionId);
}

static size_t MR_SetRecordToStep(Execution* e, size_t stepIndex, Record* r) {
    RedisModule_Assert(stepIndex < array_len(e->steps));
    Step* s = e->steps + stepIndex;
    switch (s->bStep.type) {
    case StepType_Reshuffle:
        s->reshuffle.pendingRecords = array_append(s->reshuffle.pendingRecords, r);
        return array_len(s->reshuffle.pendingRecords);
    case StepType_Collect:
        s->collect.collectedRecords = array_append(s->collect.collectedRecords, r);
        return array_len(s->collect.collectedRecords);
    }
    RedisModule_Assert(0);
    return 0;
}

static size_t MR_PerformStepDoneOp(Execution* e, size_t stepIndex) {
    RedisModule_Assert(stepIndex < array_len(e->steps));
    Step* s = e->steps + stepIndex;
    switch (s->bStep.type) {
        case StepType_Reshuffle:        return ++s->reshuffle.nDone;
        case StepType_Collect:          return ++s->collect.nDone;
        case StepType_InternalCommand:  return ++s->internalCommand.nDone;
    }
    RedisModule_Assert(0);
    return 0;
}

/* Execution task */
static bool MR_StepDone(Execution* e, void* pd) {
    RedisModuleString* payload = pd;

    /* deserialize record, set it on the right step. */
    size_t dataLen;
    const char* data = RedisModule_StringPtrLen(payload, &dataLen);
    mr_Buffer buff = (mr_Buffer){
            .buff = (char*)data,
            .size = dataLen,
            .cap = dataLen,
    };
    mr_BufferReader reader;
    mr_BufferReaderInit(&reader, &buff);
    size_t executionIdLen;
    const char* executionId = mr_BufferReaderReadBuff(&reader, &executionIdLen, NULL);
    RedisModule_Assert(executionIdLen == ID_LEN);

    size_t stepIndex = mr_BufferReaderReadLongLong(&reader, NULL);

    RedisModule_ThreadSafeContextLock(mr_staticCtx);
    RedisModule_FreeString(NULL, payload);
    RedisModule_ThreadSafeContextUnlock(mr_staticCtx);

    if (MR_PerformStepDoneOp(e, stepIndex) == MR_ClusterGetSize() - 1){
        /* All shards are done running the step, we can continue the execution. */
        MR_RunExecution(e, NULL);
    }
    return false;  // never disposes the execution here
}

/* Execution task */
static bool MR_SetRecord(Execution* e, void* pd) {
    RedisModuleString* payload = pd;

    /* deserialize record, set it on the right step. */
    size_t dataLen;
    const char* data = RedisModule_StringPtrLen(payload, &dataLen);
    mr_Buffer buff = (mr_Buffer){
            .buff = (char*)data,
            .size = dataLen,
            .cap = dataLen,
    };
    mr_BufferReader reader;
    mr_BufferReaderInit(&reader, &buff);
    size_t executionIdLen;
    const char* executionId = mr_BufferReaderReadBuff(&reader, &executionIdLen, NULL);
    RedisModule_Assert(executionIdLen == ID_LEN);

    size_t stepIndex = mr_BufferReaderReadLongLong(&reader, NULL);

    Record* r = MR_RecordDeSerialize(&reader);

    RedisModule_ThreadSafeContextLock(mr_staticCtx);
    RedisModule_FreeString(NULL, payload);
    RedisModule_ThreadSafeContextUnlock(mr_staticCtx);

    if (MR_SetRecordToStep(e, stepIndex, r) > 10000){
        /* There is enough records to process, lets continue running. */
        MR_RunExecution(e, NULL);
    }
    return false;  // never disposes the execution here
}

/* Remote function call, runs on the event loop */
static void MR_PassRecord(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t dataLen;
    const char* data = RedisModule_StringPtrLen(payload, &dataLen);
    Execution* e = MR_GetExecution(data, dataLen);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    /* run the execution on the thread pool */
    MR_ExecutionAddTask(e, MR_SetRecord, RedisModule_HoldString(NULL, payload));
}

static void MR_SendRecordToSlot(Execution* e, Step* s, Record* r, size_t slot) {
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);
    /* write the execution id */
    mr_BufferWriterWriteBuff(&buffWriter, e->id, ID_LEN);
    /* write the step index to add the record to */
    mr_BufferWriterWriteLongLong(&buffWriter, s->index);
    /* Write the record */
    MR_RecordSerialize(r, &buffWriter);

    MR_ClusterSendMsgBySlot(slot, PASS_RECORD_FUNCTION_ID, buff.buff, buff.size);
}

static void MR_SendRecord(Execution* e, Step* s, Record* r, const char* nodeId) {
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);
    /* write the execution id */
    mr_BufferWriterWriteBuff(&buffWriter, e->id, ID_LEN);
    /* write the step index to add the record to */
    mr_BufferWriterWriteLongLong(&buffWriter, s->index);
    /* Write the record */
    MR_RecordSerialize(r, &buffWriter);

    MR_ClusterSendMsg(nodeId, PASS_RECORD_FUNCTION_ID, buff.buff, buff.size);
}

/* Remote function call, runs on the event loop */
static void MR_NotifyStepDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t dataLen;
    const char* data = RedisModule_StringPtrLen(payload, &dataLen);
    Execution* e = MR_GetExecution(data, dataLen);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    /* run the execution on the thread pool */
    MR_ExecutionAddTask(e, MR_StepDone, RedisModule_HoldString(NULL, payload));
}

static Record* MR_RunReshuffleStep(Execution* e, Step* s) {
    while (1) {
        Record* r = MR_RunStep(e, s->child);
        if ((e->flags & ExecutionFlag_Local) || MR_IsError(r) || MR_IsHold(r)) {
            /* on local execution, reshuffle does nothing */
            return r;
        }

        if (r) {
            size_t hslot = MR_RecordGetHslot(r);
            if (MR_ClusterIsMySlot(hslot)) {
                /* We own the record, lets continue processing the it. */
                return r;
            }
            /* send record to the initiator */
            MR_SendRecordToSlot(e, s, r, hslot);
            /* we pass the record, we can free it now */
            MR_RecordFree(r);
            continue;
        }

        if (!s->reshuffle.sentDoneMsg) {
            /* send step done to the initiator */
            mr_Buffer buff;
            mr_BufferInitialize(&buff);
            mr_BufferWriter buffWriter;
            mr_BufferWriterInit(&buffWriter, &buff);
            /* write the execution id */
            mr_BufferWriterWriteBuff(&buffWriter, e->id, ID_LEN);
            /* write the step index */
            mr_BufferWriterWriteLongLong(&buffWriter, s->index);
            MR_ClusterSendMsg(NULL, NOTIFY_STEP_DONE_FUNCTION_ID, buff.buff, buff.size);
            s->reshuffle.sentDoneMsg = 1;
        }

        if (array_len(s->reshuffle.pendingRecords) > 0) {
            /* process Records that came from other shards */
            return array_pop(s->reshuffle.pendingRecords);
        }

        if (s->reshuffle.nDone == MR_ClusterGetSize() - 1) {
            /* all shards finished sending all the record, we are done. */
            s->flags |= StepFlag_Done;
            return NULL;
        } else {
            /* hold the execution, wait for shards to send data */
            return MR_HoldRecordGet();
        }
    }
}

static Record* MR_RunAccumulateStep(Execution* e, Step* s) {
    while (1) {
        Record* r = MR_RunStep(e, s->child);
        if (MR_IsError(r) || MR_IsHold(r)) {
            return r;
        }

        if (!r) {
            r = s->accumulate.accumulator;
            s->accumulate.accumulator = NULL;
            s->flags |= StepFlag_Done;
            return r;
        }

        ExecutionCtx eCtx = {
            .e = e,
            .err = NULL,
        };
        s->accumulate.accumulator = s->accumulate.accumulateCallback(&eCtx, s->accumulate.accumulator, r, s->bStep.args);
        if (eCtx.err){
            return eCtx.err;
        }
    }
}

static Record* MR_RunCollectStep(Execution* e, Step* s) {
    while (1) {
        Record* r = MR_RunStep(e, s->child);
        if ((e->flags & ExecutionFlag_Local) || MR_IsHold(r)) {
            /* on local execution, collect does nothing */
            return r;
        }

        if (r) {
            if (e->flags & ExecutionFlag_Initiator) {
                /* We are the initiator, lets continue processing the Record. */
                return r;
            }
            /* send record to the initiator */
            MR_SendRecord(e, s, r, e->id);
            /* we pass the record to the initiator, we can free it now */
            MR_RecordFree(r);
            continue;
        }

        if (!(e->flags & ExecutionFlag_Initiator)) {
            /* send step done to the initiator */
            mr_Buffer buff;
            mr_BufferInitialize(&buff);
            mr_BufferWriter buffWriter;
            mr_BufferWriterInit(&buffWriter, &buff);
            /* write the execution id */
            mr_BufferWriterWriteBuff(&buffWriter, e->id, ID_LEN);
            /* write the step index to add the record to */
            mr_BufferWriterWriteLongLong(&buffWriter, s->index);
            MR_ClusterSendMsg(e->id, NOTIFY_STEP_DONE_FUNCTION_ID, buff.buff, buff.size);
            /* we are not the initiator, we have nothing to give here */
            s->flags |= StepFlag_Done;
            return NULL;
        }

        if (array_len(s->collect.collectedRecords) > 0) {
            /* process Records that came from other shards */
            return array_pop(s->collect.collectedRecords);
        }

        if (s->collect.nDone == MR_ClusterGetSize() - 1) {
            /* all shards finished sending all the record, we are done. */
            s->flags |= StepFlag_Done;
            return NULL;
        } else {
            /* hold the execution, wait for shards to send data */
            return MR_HoldRecordGet();
        }
    }
}

static Record* MR_RunFilterStep(Execution* e, Step* s) {
    while (1) {
        Record* r = MR_RunStep(e, s->child);
        if (MR_IsError(r) || MR_IsHold(r)) {
            return r;
        }
        if (!r) {
            s->flags |= StepFlag_Done;
            return NULL;
        }
        ExecutionCtx eCtx = {
            .e = e,
            .err = NULL,
        };
        int res = s->filter.filterCallback(&eCtx, r, s->bStep.args);
        if (eCtx.err){
            MR_RecordFree(r);
            return eCtx.err;
        }
        if (!res) {
            MR_RecordFree(r);
        } else {
            return r;
        }
    }
}

static Record* MR_RunMapStep(Execution* e, Step* s) {
    Record* r = MR_RunStep(e, s->child);
    if (MR_IsError(r) || MR_IsHold(r)) {
        return r;
    }
    if (!r) {
        s->flags |= StepFlag_Done;
        return NULL;
    }
    ExecutionCtx eCtx = {
        .e = e,
        .err = NULL,
    };
    r = s->map.mapCallback(&eCtx, r, s->bStep.args);
    if (eCtx.err) {
        return eCtx.err;
    }
    return r;
}

static Record* MR_RunReaderStep(Execution* e, Step* s) {
    ExecutionCtx eCtx = {
        .e = e,
        .err = NULL,
    };
    Record* r = s->read.readCallback(&eCtx, s->bStep.args);
    if (eCtx.err) {
        return eCtx.err;
    }
    if (!r) {
        s->flags |= StepFlag_Done;
    }
    return r;
}

static Record* MR_RunStep(Execution* e, Step* s) {
    if (s->flags & StepFlag_Done) {
        return NULL;
    }
    switch(s->bStep.type){
    case StepType_Reader:
        return MR_RunReaderStep(e, s);
    case StepType_Mapper:
        return MR_RunMapStep(e, s);
    case StepType_Filter:
        return MR_RunFilterStep(e, s);
    case StepType_Reshuffle:
        return MR_RunReshuffleStep(e, s);
    case StepType_Collect:
        return MR_RunCollectStep(e, s);
    case StepType_Accumulator:
        return MR_RunAccumulateStep(e, s);
    case StepType_InternalCommand:
        RedisModule_Assert(false);  // Steps of internal commands are done in the el thread, not here
    }
    RedisModule_Assert(false);
    return NULL;
}

static int MR_RunExecutionInternal(Execution* e) {
    Step* lastStep = e->steps + array_len(e->steps) - 1;
    while (1) {
        Record* record = MR_RunStep(e, lastStep);
        if (MR_IsError(record)) {
            e->errors = array_append(e->errors, record);
            continue;
        }
        if (MR_IsHold(record)) {
            return 0;
        }

        if (!record) {
            /* record is NULL, we are done. */
            return 1;
        }
        e->results = array_append(e->results, record);
    }
    RedisModule_Assert(false);
    return 1;
}

static bool MR_ExecutionInvokeCallback(Execution* e, ExecutionCallbackData* callback) {
    if (!callback || !callback->callback)
        return false;

    ExecutionCtx eCtx = {
            .e = e,
            .err = NULL
    };
    callback->callback(&eCtx, callback->pd);
    return true;
}

static bool MR_DisposeExecution(Execution* e, void* pd) {
    MR_FreeExecution(e);
    return true;  // always disposes the execution
}

/* runs on the event loop, remove the execution from the
 * executions dictionary and send a dispose task */
static void MR_DeleteExecution(void* ctx) {
    Execution* e = ctx;
    mr_dictDelete(mrCtx.executionsDict, e->id);
    /* Send dispose execution task, this will be last task this execution will ever receive. */
    MR_ExecutionAddTask(e, MR_DisposeExecution, NULL);
}

/* Remote function call, runs on the event loop */
static void MR_DropExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t idLen;
    const char* executionId = RedisModule_StringPtrLen(payload, &idLen);
    RedisModule_Assert(idLen == ID_LEN);

    Execution* e = mr_dictFetchValue(mrCtx.executionsDict, executionId);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    MR_DeleteExecution(e);
}

/* Remote function call, runs on the event loop */
static void MR_NotifyDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t idLen;
    const char* executionId = RedisModule_StringPtrLen(payload, &idLen);
    RedisModule_Assert(idLen == ID_LEN);

    Execution* e = mr_dictFetchValue(mrCtx.executionsDict, executionId);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    ++e->nCompleted;
    if (e->nCompleted == MR_ClusterGetSize() - 1) {
        /* Execution is finished on all the shards,
         * We will not receive any more messages on it.
         * We can ask all the shards to drop it and we can
         * drop it ourself. */
        MR_ClusterCopyAndSendMsg(NULL, DROP_EXECUTION_FUNCTION_ID, e->id, ID_LEN);
        MR_DeleteExecution(e);
    }
}

static bool MR_RunExecution(Execution* e, void* pd) {
    MR_ExecutionInvokeCallback(e, &e->callbacks.resume);
    if (MR_RunExecutionInternal(e)) {
        /* we are done, invoke on done callback and perform termination process. */
        bool doneInvoked = MR_ExecutionInvokeCallback(e, &e->callbacks.done);
        e->callbacks.done.callback = NULL; // make sure the done callback will not be called again.
        if (doneInvoked) {
            bool executionDone = (e->flags & ExecutionFlag_Local) != 0;   // either no need to wait to any shard
            executionDone = executionDone || MR_IsInternalCommandsExecution(e); // or we don't need a NOTIFY_DONE message
            if (executionDone) {
                MR_EventLoopAddTask(MR_DeleteExecution, e);
                return false;  // disposal happens later via MR_DeleteExecution -> MR_DisposeExecution
            }
        }
        if (!(e->flags & ExecutionFlag_Initiator)) {
            MR_ClusterCopyAndSendMsg(e->id, NOTIFY_DONE_FUNCTION_ID, e->id, ID_LEN);
        }
    } else {
        MR_ExecutionInvokeCallback(e, &e->callbacks.hold);
    }
    return false;  // never disposes the execution here
}

/* Remote function call, runs on the event loop */
static void MR_InvokeExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t idLen;
    const char* executionId = RedisModule_StringPtrLen(payload, &idLen);
    RedisModule_Assert(idLen == ID_LEN);

    Execution* e = mr_dictFetchValue(mrCtx.executionsDict, executionId);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    /* run the execution on the thread pool */
    MR_ExecutionAddTask(e, MR_RunExecution, NULL);
}

/* Remote function call, runs on the event loop */
static void MR_AckExecution(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t idLen;
    const char* executionId = RedisModule_StringPtrLen(payload, &idLen);
    RedisModule_Assert(idLen == ID_LEN);

    Execution* e = mr_dictFetchValue(mrCtx.executionsDict, executionId);
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    ++e->nReceived;
    if (e->nReceived == MR_ClusterGetSize() - 1) {
        /* all shards have received the execution, we can invoke it. */
        MR_ClusterCopyAndSendMsg(NULL, INVOKE_EXECUTION_FUNCTION_ID, e->id, ID_LEN);
        /* run the execution on the thread pool */
        MR_ExecutionAddTask(e, MR_RunExecution, NULL);
    }
}

/* Runs in the event loop, save the execution
 * in the executions dictionary. Send ack on
 * receiving the execution to the initiator */
static void MR_ReceivedExecution(void* ctx) {
    Execution* e = ctx;

    /* add the execution to the execution dictionary */
    mr_dictAdd(mrCtx.executionsDict, e->id, e);

    /* tell the initiator that we received the execution */
    MR_ClusterCopyAndSendMsg(e->id, ACK_EXECUTION_FUNCTION_ID, e->id, ID_LEN);
}

static Execution* MR_ExecutionDeserialize(mr_BufferReader* buffReader) {
    size_t executionIdLen;
    const char* executionId = mr_BufferReaderReadBuff(buffReader, &executionIdLen, NULL);
    RedisModule_Assert(executionIdLen == ID_LEN);
    size_t maxIdle = mr_BufferReaderReadLongLong(buffReader, NULL);
    size_t nSteps = mr_BufferReaderReadLongLong(buffReader, NULL);

    Execution* e = MR_ExecutionAlloc();
    memcpy(e->id, executionId, ID_LEN);
    snprintf(e->idStr, STR_ID_LEN, "%.*s-%lld", REDISMODULE_NODE_ID_LEN, e->id, *(long long*)&e->id[REDISMODULE_NODE_ID_LEN]);
    e->timeoutMS = maxIdle;

    Step* child = NULL;
    for (size_t i = 0 ; i < nSteps ; ++i) {
        Step s;
        s.bStep.type = mr_BufferReaderReadLongLong(buffReader, NULL);
        if (mr_BufferReaderReadLongLong(buffReader, NULL)) {
            /* read step name */
            s.bStep.name = MR_STRDUP(mr_BufferReaderReadString(buffReader, NULL));
        } else {
            s.bStep.name = NULL;
        }

        StepDefinition* sd = MR_GetStepDefinition(s.bStep.type, s.bStep.name);
        if (sd) {
            s.bStep.argsType = sd->type;
        } else {
            s.bStep.argsType = NULL;
        }

        if (mr_BufferReaderReadLongLong(buffReader, NULL)) {
            /* read step args */
            MRError* err = NULL;
            s.bStep.args = s.bStep.argsType->deserialize(buffReader, &err);
            // todo: handle deserialization failure
            RedisModule_Assert(!err);
        } else {
            s.bStep.args = NULL;
        }

        MR_InitializeFromStepDef(&s, sd);
        s.flags = 0;
        s.index = i;
        s.child = child;
        e->steps = array_append(e->steps, s);
        child = e->steps + array_len(e->steps) - 1;
    }
    return e;
}

/* Runs on redis-server's main loop */
int MR_ClusterExecuteInternalCommands(RedisModuleCtx *ctx, RedisModuleString *msg) {
    size_t dataSize;
    const char* data = RedisModule_StringPtrLen(msg, &dataSize);
    mr_Buffer buff = {
            .buff = (char*)data,
            .size = dataSize,
            .cap = dataSize,
    };
    mr_BufferReader buffReader;
    mr_BufferReaderInit(&buffReader, &buff);
    Execution* e = MR_ExecutionDeserialize(&buffReader);
    RedisModule_ReplyWithArray(ctx, array_len(e->steps));
    for (int i = 0; i < array_len(e->steps); i++) {
        Step *s = e->steps + i;
        RedisModule_Assert(s->bStep.type == StepType_InternalCommand);
        s->internalCommand.command(ctx, s->bStep.args);
    }
    MR_FreeExecution(e);
    return REDISMODULE_OK;
}

/* Runs on the event loop */
void MR_SetInternalCommandResults(unsigned short nodeIndex, redisReply* reply, Execution *e) {
    // Since this function is a callback for hiredis the reply will vanish when we return.
    // Instead of copying it and then invoke executions tasks to parse the replies we simply
    // parse them here (in the el thread) and leave only the aggregation part (i.e., after all
    // the nodes have answered) to a worker thread (in the Execution's on-done handler callback).
    if (!e) {
        ++mrCtx.stats.nMissedExecutions;
        return;
    }

    RedisModule_Assert(reply->type == REDIS_REPLY_ARRAY && reply->elements > 0);
    RedisModule_Assert(array_len(e->steps) == reply->elements);
    size_t nodesDone = 0;
    for (size_t i = 0; i < reply->elements; i++) {
        Step *s = e->steps + i;
        s->internalCommand.reply = reply->element[i];

        // Per-element error: one internal command failed (e.g. NOPERM on a key).
        // Capture the error instead of calling the replyParser.
        if (s->internalCommand.reply->type == REDIS_REPLY_ERROR) {
            e->errors = array_append(e->errors, MR_ErrorRecordCreate(s->internalCommand.reply->str));
            s->internalCommand.reply = NULL;
        } else {
            Record *record = s->internalCommand.replyParser(s->internalCommand.reply);
            s->internalCommand.reply = NULL;
            e->results = array_append(e->results, record);
        }

        if (nodesDone == 0)
            nodesDone = MR_PerformStepDoneOp(e, i);
        else if (nodesDone != MR_PerformStepDoneOp(e, i))
            RedisModule_Assert(false);
        s->flags |= StepFlag_Done;
    }

    if (nodesDone == MR_ClusterGetSize()) {
        MR_ExecutionAddTask(e, MR_RunExecution, NULL);
    }
}

static void MR_ReceiveExecution(void* pd) {
    RedisModuleString* payload = pd;
    size_t dataSize;
    const char* data = RedisModule_StringPtrLen(payload, &dataSize);
    mr_Buffer buff = {
            .buff = (char*)data,
            .size = dataSize,
            .cap = dataSize,
    };
    mr_BufferReader buffReader;
    mr_BufferReaderInit(&buffReader, &buff);
    Execution* e = MR_ExecutionDeserialize(&buffReader);

    /* We must take the Redis GIL to free the payload,
     * RedisModuleString refcount are not thread safe.
     * We better do it here and stuck on of the threads
     * in the thread pool then do it on the event loop.
     * Possible optimization would be to batch multiple
     * payloads into one GIL locking */
    RedisModule_ThreadSafeContextLock(mr_staticCtx);
    RedisModule_FreeString(NULL, payload);
    RedisModule_ThreadSafeContextUnlock(mr_staticCtx);

    /* Finish deserializing the execution, we need to
     * return to the event loop and save the execution
     * in the executions dictionary */
    MR_EventLoopAddTask(MR_ReceivedExecution, e);

}

/* Remote function call, runs on the event loop */
static void MR_NewExecutionReceived(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    /* We can directly move the job to the thread pool.
     * We need to deserialize the execution and reply to the initiator. */
    mr_thpool_add_work(mrCtx.executionsThreadPool, MR_ReceiveExecution, RedisModule_HoldString(NULL, payload));
}

static void MR_ExecutionStepSerialize(mr_BufferWriter* buffWriter, Step* s) {
    mr_BufferWriterWriteLongLong(buffWriter, s->bStep.type); /* write the step type */
    if (s->bStep.name) {
        mr_BufferWriterWriteLongLong(buffWriter, 1); /* name exists */
        mr_BufferWriterWriteString(buffWriter, s->bStep.name); /* write the step name */
    } else {
        mr_BufferWriterWriteLongLong(buffWriter, 0); /* name does not exists */
    }
    /* serialize step args */
    if (s->bStep.args) {
        mr_BufferWriterWriteLongLong(buffWriter, 1); /* args exists */
        MRError* err = NULL;
        s->bStep.argsType->serialize(buffWriter, s->bStep.args, &err);
        // todo: handle serialization failure
        RedisModule_Assert(!err);
    } else {
        mr_BufferWriterWriteLongLong(buffWriter, 0); /* args does not exists */
    }
}

static void MR_ExecutionSerialize(mr_BufferWriter* buffWriter, Execution* e) {
    mr_BufferWriterWriteBuff(buffWriter, e->id, ID_LEN); /* write the execution id */
    mr_BufferWriterWriteLongLong(buffWriter, e->timeoutMS); /* max idle time */
    mr_BufferWriterWriteLongLong(buffWriter, array_len(e->steps)); /* number of steps */
    for (size_t i = 0 ; i < array_len(e->steps) ; ++i) {
        MR_ExecutionStepSerialize(buffWriter, e->steps + i);
    }
}

/* Execution task distribute callback */
static bool MR_ExecutionDistribute(Execution* e, void* pd) {
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);
    MR_ExecutionSerialize(&buffWriter, e);
    functionId fid = NEW_EXECUTION_RECEIVED_FUNCTION_ID;
    if (MR_IsInternalCommandsExecution(e)) {
        // We signal it to the INNER_COMMUNICATION handler function using this tiny hack:
        fid |= FUNCTION_ID_INTERNAL;
    }
    MR_ClusterSendMsg(NULL, fid, buff.buff, buff.size);

    /* now we wait for shards to respond that they got the execution */
    return false;  // never disposes the execution here
}

static bool MR_ExecutionTimedOutInternal(Execution* e, void* pd) {
    e->errors = array_append(e->errors, MR_ErrorRecordCreate("execution max idle reached"));
    /* We are done: invoke the on-done callback and free the execution. If the done
     * callback was already fired (a normal completion won the race and nulled it),
     * a MR_DisposeExecution is already queued to free the execution - so we must NOT
     * free it here (that would double-free). Return false so MR_ExecutionMain keeps
     * draining the task queue and that pending MR_DisposeExecution still runs;
     * otherwise the execution (and its results) would leak. */
    if (!MR_ExecutionInvokeCallback(e, &e->callbacks.done))
        return false;
    e->callbacks.done.callback = NULL; // make sure the done callback will not be called again.
    MR_FreeExecution(e);
    return true;
}

/* runs on the event loop */
static void MR_ExecutionTimedOut(void* ctx) {
    Execution* e = ctx;
    /* execution timed out */
    e->timeoutTask = NULL;
    ++mrCtx.stats.nMaxIdleReached;
    /* Delete the execution from the executions dictionary,
     * We will ignore further messages on this execution. */
    mr_dictDelete(mrCtx.executionsDict, e->id);
    MR_ExecutionAddTask(e, MR_ExecutionTimedOutInternal, NULL);
}

// Thread pool task: fires the done callback with a cluster topology change error
static bool MR_ExecutionAbortedOnClusterChange(Execution* e, void* pd) {
    e->errors = array_append(e->errors, MR_ErrorRecordCreate("cluster topology changed"));
    /* We are done: invoke the on-done callback and free the execution. If the done
     * callback was already fired (a normal completion won the race and nulled it),
     * a MR_DisposeExecution is already queued to free the execution - so we must NOT
     * free it here (that would double-free, or free out from under the queued
     * MR_DeleteExecution which still dereferences e -> use-after-free). Return false so
     * MR_ExecutionMain keeps draining the task queue and that pending MR_DisposeExecution
     * still runs; otherwise the execution (and its results) would leak. */
    if (!MR_ExecutionInvokeCallback(e, &e->callbacks.done))
        return false;
    e->callbacks.done.callback = NULL; /* make sure the done callback will not be called again */
    MR_FreeExecution(e);
    return true;
}

static void MR_ExecutionMain(void* pd) {
    Execution* e = pd;
    pthread_mutex_lock(&e->eLock);
    mr_listNode *head = mr_listFirst(e->tasks);
    ExecutionTask* task = mr_listNodeValue(head);
    pthread_mutex_unlock(&e->eLock);

    ExecutionTaskCallback callback = task->callback;
    if (callback(e, task->pd)) {
        // The callback disposed (freed) the execution; we must not touch it afterwards.
        // Note: MR_ExecutionTimedOutInternal / MR_ExecutionAbortedOnClusterChange return
        // false (do NOT dispose) when their done callback was already fired by a racing
        // normal completion, which leaves a MR_DisposeExecution queued behind this task.
        // Falling through in that case lets us drain the queue so that pending
        // MR_DisposeExecution runs and frees the execution (otherwise it would leak).
        return;
    }

    // A terminal handler (idle-timeout / cluster-abort) that returned false did not
    // dispose e, but it has already removed e from executionsDict. We still drain any
    // task queued behind it (e.g. a MR_DisposeExecution from a racing normal completion),
    // but we must NOT re-arm the idle timer for such an execution: nothing can cancel it
    // anymore, so it would re-fire forever (appending to e->errors every tick). A pending
    // MR_DisposeExecution, if one was queued, still runs and frees e.
    bool terminal = (callback == MR_ExecutionTimedOutInternal ||
                     callback == MR_ExecutionAbortedOnClusterChange);

    pthread_mutex_lock(&e->eLock);
    /* pop current task out */
    mr_listDelNode(e->tasks, head);

    /* check if there are more tasks to run */
    if (mr_listLength(e->tasks) > 0) {
        /* more work to do, for fairness we will not run now.
         * We will add ourselves to the thread pool */
        mr_thpool_add_work(mrCtx.executionsThreadPool, MR_ExecutionMain, e);
    } else if (!terminal) {
        e->timeoutTask = MR_EventLoopAddTaskWithDelay(MR_ExecutionTimedOut, e, e->timeoutMS);
    }

    pthread_mutex_unlock(&e->eLock);
}

/* should be invoked only from the event loop */
static void MR_ExecutionAddTask(Execution* e, ExecutionTaskCallback callback, void* pd) {
    ExecutionTask* task = MR_ALLOC(sizeof(*task));
    task->callback = callback;
    task->pd = pd;
    pthread_mutex_lock(&e->eLock);
    if (e->timeoutTask) {
        MR_EventLoopDelayTaskCancel(e->timeoutTask);
        e->timeoutTask = NULL;
    }
    size_t lenBeforeTask = mr_listLength(e->tasks);
    mr_listAddNodeTail(e->tasks, task);

    if (lenBeforeTask == 0) {
        /* nothing is currently running, add a task to the thread pool */
        mr_thpool_add_work(mrCtx.executionsThreadPool, MR_ExecutionMain, e);
    }

    pthread_mutex_unlock(&e->eLock);
}

/* Happens on the event loop,
 * Preper the execution to run and send
 * it to run on the thread pool. */
static void MR_ExecutionStart(void* ctx) {
    Execution* e = ctx;

    /* add the execution to the execution dictionary */
    mr_dictAdd(mrCtx.executionsDict, e->id, e);

    if (e->flags & ExecutionFlag_Local) {
        /* not need to distribute the execution,
         * we can simply start running it.
         * Note: it will run in the event-loop thread! */
        MR_ExecutionAddTask(e, MR_RunExecution, NULL);
    } else {
        MR_ExecutionAddTask(e, MR_ExecutionDistribute, NULL);
    }
}

void MR_ExecutionSetOnDoneHandler(Execution* e, ExecutionCallback onDone, void* pd) {
    e->callbacks.done = (ExecutionCallbackData){
        .callback = onDone,
        .pd = pd,
    };
}

void MR_ExecutionSetMaxIdle(Execution* e, size_t maxIdle) {
    e->timeoutMS = maxIdle;
}

void MR_Run(Execution* e) {
    /* take ownership on the execution */
    __atomic_add_fetch(&e->refCount, 1, __ATOMIC_RELAXED);

    /* add the execution to the event loop */
    MR_EventLoopAddTask(MR_ExecutionStart, e);
}

bool MR_IsInternalCommandsExecution(const Execution* e) {
    return array_len(e->steps) > 0 && e->steps[0].bStep.type == StepType_InternalCommand;
    // This means all steps are internal commands (because we do not allow to mix them with other step types)
}

Record* MR_ExecutionCtxGetResult(ExecutionCtx* ectx, size_t i) {
    return ectx->e->results[i];
}

size_t MR_ExecutionCtxGetResultsLen(ExecutionCtx* ectx) {
    return array_len(ectx->e->results);
}

const char* MR_ExecutionCtxGetError(ExecutionCtx* ectx, size_t i) {
    return MR_ErrorRecordGetError(ectx->e->errors[i]);
}

size_t MR_ExecutionCtxGetErrorsLen(ExecutionCtx* ectx){
    return array_len(ectx->e->errors);
}

LIBMR_API void MR_ExecutionCtxSetError(ExecutionCtx* ectx, const char* err, size_t len) {
    char error[len + 1];
    memcpy(error, err, len);
    error[len] = '\0';
    ectx->err = MR_ErrorRecordCreate(error);
}

LIBMR_API void MR_AbortRunningExecutions(void) {
    // Collect pointers first to avoid mutating the dict while iterating
    ARR(Execution*) to_abort = array_new(Execution*, 10);
    mr_dictIterator* iter = mr_dictGetIterator(mrCtx.executionsDict);
    mr_dictEntry* entry;
    while ((entry = mr_dictNext(iter))) {
        Execution* e = mr_dictGetVal(entry);
        // We only care about the initiator execution (i.e., to respond an error to the client immediately).
        // If there are running executions on other nodes, they will be cleaned upon completion or timeout.
        if (e->flags & ExecutionFlag_Initiator)
            to_abort = array_append(to_abort, e);
    }
    mr_dictReleaseIterator(iter);

    for (size_t i = 0; i < array_len(to_abort); ++i) {
        Execution* e = to_abort[i];
        // Cancel the pending idle-timeout timer if it is already armed
        if (e->timeoutTask) {
            MR_EventLoopDelayTaskCancel(e->timeoutTask);
            e->timeoutTask = NULL;
        }
        mr_dictDelete(mrCtx.executionsDict, e->id);
        MR_ExecutionAddTask(e, MR_ExecutionAbortedOnClusterChange, NULL);
    }
    array_free(to_abort);
}

static void MR_StepDispose(Step* s) {
    if (s->bStep.name) {
        MR_FREE(s->bStep.name);
    }
    if (s->bStep.args) {
        s->bStep.argsType->free(s->bStep.args);
    }
    switch (s->bStep.type) {
    case StepType_Mapper:
    case StepType_Filter:
    case StepType_Reader:
    case StepType_InternalCommand:
        break;
    case StepType_Accumulator:
        if (s->accumulate.accumulator) {
            MR_RecordFree(s->accumulate.accumulator);
        }
        break;
    case StepType_Reshuffle:
        for (size_t i = 0 ; i < array_len(s->reshuffle.pendingRecords) ; ++i){
            MR_RecordFree(s->reshuffle.pendingRecords[i]);
        }
        array_free(s->reshuffle.pendingRecords);
        break;
    case StepType_Collect:
        for (size_t i = 0 ; i < array_len(s->collect.collectedRecords) ; ++i){
            MR_RecordFree(s->collect.collectedRecords[i]);
        }
        array_free(s->collect.collectedRecords);
        break;
    default:
        RedisModule_Assert(0);
    }
}

void MR_FreeExecution(Execution* e) {
    if (__atomic_sub_fetch(&e->refCount, 1, __ATOMIC_RELAXED) > 0) {
        return;
    }
    for (size_t i = 0 ; i < array_len(e->steps) ; ++i) {
        MR_StepDispose(e->steps + i);
    }
    array_free(e->steps);
    mr_listRelease(e->tasks);
    for (size_t i = 0 ; i < array_len(e->results) ; ++i) {
        MR_RecordFree(e->results[i]);
    }
    array_free(e->results);
    for (size_t i = 0 ; i < array_len(e->errors) ; ++i) {
        MR_RecordFree(e->errors[i]);
    }
    array_free(e->errors);
    MR_FREE(e);
}

void MR_UpdateClusterTopology() {
    MR_TopologyEventSeen = true;
    RedisModuleString** argv = NULL;
    int argc = 1;  // The first one is always the command name, so no need any argv for that
    const char *password = MR_ClusterGetPassword();

    // Updating the cluster topology is split across two threads:
    // 1. Redis' main thread (here): build the candidate topology and verify its
    //    integrity (MR_BuildCluster() returns non-NULL only if the topology is valid).
    // 2. The event-loop thread (in the lock-protected MR_UpdateClusterTopologyIfNeeded): compare the
    //    candidate against the installed clusterCtx.CurrCluster and swap it in
    //    (alongside other fields, e.g., .clusterSize) only if it changed.
    //    Since this step reads and writes the cluster context it must run on the event-loop thread.
    //
    // Because the comparison runs later on the event-loop thread, this function
    // cannot return a boolean indicating whether the topology actually changed or not
    // so it returns nothing.
    Cluster *cluster = MR_BuildCluster(argv, argc, password);
    if (cluster == NULL)
        return;
    MR_EventLoopAddTask(MR_UpdateClusterTopologyIfNeededUnderLock, cluster);
}

static void MR_GetRedisVersion() {
    RedisModuleCallReply *reply = RedisModule_Call(mr_staticCtx, "info", "c", "server");
    assert(RedisModule_CallReplyType(reply) == REDISMODULE_REPLY_STRING);
    size_t len;
    const char *replyStr = RedisModule_CallReplyStringPtr(reply, &len);

    int n = sscanf(replyStr,
                   "# Server\nredis_version:%d.%d.%d",
                   &MR_currVersion.redisMajorVersion,
                   &MR_currVersion.redisMinorVersion,
                   &MR_currVersion.redisPatchVersion);
    if (n != 3) {
        RedisModule_Log(NULL, "warning", "Could not extract redis version");
    }

    MR_RlecMajorVersion = -1;
    MR_RlecMinorVersion = -1;
    MR_RlecPatchVersion = -1;
    MR_RlecBuild = -1;
    const char *enterpriseStr = strstr(replyStr, "rlec_version:");
    /* Presence of the rlec_version field is the enterprise signal, independent
     * of whether the version numbers below parse. Record it separately so a
     * present-but-unparseable value isn't mistaken for an OSS build. */
    MR_RlecVersionPresent = (enterpriseStr != NULL);
    if (enterpriseStr) {
        n = sscanf(enterpriseStr,
                   "rlec_version:%d.%d.%d-%d",
                   &MR_RlecMajorVersion,
                   &MR_RlecMinorVersion,
                   &MR_RlecPatchVersion,
                   &MR_RlecBuild);
        if (n != 4) {
            RedisModule_Log(NULL, "warning", "Could not extract enterprise version");
        }
    }

    RedisModule_FreeCallReply(reply);
}

int MR_Init(RedisModuleCtx* ctx, size_t numThreads, char *password, bool topologyEvents) {
    mr_staticCtx = RedisModule_GetDetachedThreadSafeContext(ctx);
    MR_GetRedisVersion();

    if (MR_ClusterInit(ctx, password, topologyEvents) != REDISMODULE_OK) {
        return REDISMODULE_ERR;
    }

    mrCtx.lastExecutionId = 0;
    mrCtx.executionsDict = mr_dictCreate(&dictTypeHeapIds, NULL);
    mrCtx.remoteDict = mr_dictCreate(&dictTypeHeapIds, NULL);

    mrCtx.objectTypesDict = array_new(MRObjectType*, 10);

    mrCtx.readerDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);
    mrCtx.mappersDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);
    mrCtx.remoteTasksDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);
    mrCtx.filtersDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);
    mrCtx.accumulatorsDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);
    mrCtx.internalCommandsDict = mr_dictCreate(&mr_dictTypeHeapStrings, NULL);

    mrCtx.executionsThreadPool = mr_thpool_init(numThreads);
    mrCtx.stats = (MRStats){
            .nMissedExecutions = 0,
            .nMaxIdleReached = 0,
    };

    for (size_t i = 0 ; i < sizeof(remoteFunctions)/sizeof(RemoteFunctionDef) ; ++i) {
        RemoteFunctionDef* rf = remoteFunctions + i;
        *(rf->funcIdPointer) = MR_ClusterRegisterMsgReceiver(rf->functionPointer);
    }

    MR_RecordInitialize();

    MR_EventLoopStart();

    return REDISMODULE_OK;
}

int MR_ResizeExecutionThreadPoolIfUnstarted(size_t numThreads) {
    mr_threadpool tp = mrCtx.executionsThreadPool;

    /* Pool is created in MR_Init(); resize cannot apply until then. */
    if (!tp) {
        return REDISMODULE_ERR;
    }

    if (mr_thpool_workers_started(tp)) {
        return REDISMODULE_ERR;
    }

    if (mr_thpool_resize_unstarted(tp, numThreads) != 0) {
        return REDISMODULE_ERR;
    }
    return REDISMODULE_OK;
}

int MR_RegisterObject(MRObjectType* t) {
    mrCtx.objectTypesDict = array_append(mrCtx.objectTypesDict, t);
    t->id = array_len(mrCtx.objectTypesDict) - 1;
    return REDISMODULE_OK;
}

LIBMR_API int MR_RegisterRecord(MRRecordType* t) {
    return MR_RegisterObject(&t->type);
}

MRObjectType* MR_GetObjectType(size_t id) {
    if (id >= array_len(mrCtx.objectTypesDict)) {
        return NULL;
    }
    return mrCtx.objectTypesDict[id];
}

void MR_RegisterReader(const char* name, ExecutionReader reader, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.readerDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = reader,
    };
    mr_dictAdd(mrCtx.readerDict, sd->name, sd);
}

void MR_RegisterInternalCommand(const char* name, InternalCommandCallbacks *callbacks, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.internalCommandsDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = callbacks
    };
    mr_dictAdd(mrCtx.internalCommandsDict, sd->name, sd);
}

void MR_RegisterMapper(const char* name, ExecutionMapper mapper, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.mappersDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = mapper,
    };
    mr_dictAdd(mrCtx.mappersDict, sd->name, sd);
}

void MR_RegisterFilter(const char* name, ExecutionFilter filter, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.filtersDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = filter,
    };
    mr_dictAdd(mrCtx.filtersDict, sd->name, sd);
}

LIBMR_API void MR_RegisterAccumulator(const char* name, ExecutionAccumulator accumulator, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.accumulatorsDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = accumulator,
    };
    mr_dictAdd(mrCtx.accumulatorsDict, sd->name, sd);
}

LIBMR_API void MR_RegisterRemoteTask(const char* name, RemoteTask remote, MRObjectType* argType) {
    RedisModule_Assert(!mr_dictFetchValue(mrCtx.remoteTasksDict, name));
    StepDefinition* sd = MR_ALLOC(sizeof(*sd));
    *sd = (StepDefinition) {
        .name = MR_STRDUP(name),
        .type = argType,
        .callback = remote,
    };
    mr_dictAdd(mrCtx.remoteTasksDict, sd->name, sd);
}

long long MR_SerializationCtxReadLongLong(ReaderSerializationCtx* sctx, MRError** err) {
    int error = 0;
    long res = mr_BufferReaderReadLongLong(sctx, &error);
    if (error) {
        *err = &BUFFER_READ_ERROR;
    }
    return res;
}

const char* MR_SerializationCtxReadBuffer(ReaderSerializationCtx* sctx, size_t* len, MRError** err) {
    int error = 0;
    const char* res = mr_BufferReaderReadBuff(sctx, len, &error);
    if (error) {
        *err = &BUFFER_READ_ERROR;
    }
    return res;
}

double MR_SerializationCtxReadDouble(ReaderSerializationCtx* sctx, MRError** err) {
    return (double)MR_SerializationCtxReadLongLong(sctx, err);
}

void MR_SerializationCtxWriteLongLong(WriteSerializationCtx* sctx, long long val, MRError** err) {
    mr_BufferWriterWriteLongLong(sctx, val);
}

void MR_SerializationCtxWriteBuffer(WriteSerializationCtx* sctx, const char* buff, size_t len, MRError** err) {
    mr_BufferWriterWriteBuff(sctx, buff, len);
}

void MR_SerializationCtxWriteDouble(WriteSerializationCtx* sctx, double val, MRError** err) {
    mr_BufferWriterWriteLongLong(sctx, (long long) val);
}

size_t MR_CalculateSlot(const char* buff, size_t len) {
    return MR_ClusterGetSlotByKey(buff, len);
}

LIBMR_API int MR_IsMySlot(size_t slot) {
    return MR_ClusterIsMySlot(slot);
}

MRError* MR_ErrorCreate(const char* msg, size_t len) {
    MRError* ret = MR_ALLOC(sizeof(*ret));
    ret->type = MRErrorType_Dynamic;
    ret->msg = MR_ALLOC(len + 1);
    memcpy(ret->msg, msg, len);
    ret->msg[len] = '\0';
    return ret;
}

const char* MR_ErrorGetMessage(MRError* err) {
    return err->msg;
}

void MR_ErrorFree(MRError* err) {
    if (err->type == MRErrorType_Dynamic) {
        MR_FREE(err->msg);
        MR_FREE(err);
    }
}

typedef struct RunOnKeyReplyMsg {
    char *sender;
    char *id;
} RunOnKeyReplyMsg;

typedef enum ReplyType {
    ReplyType_OK, ReplyType_ERROR,
}ReplyType;

typedef enum RemoteTaksMsgType {
    RemoteTaksMsgType_OnKey, RemoteTaksMsgType_OnAllShards,
} RemoteTaksMsgType;

typedef struct RemoteTaksMsg {
    char idStr[STR_ID_LEN];
    char id[ID_LEN];
    char *msg;
    size_t msgLen;
    size_t timeout;
    MR_LoopTaskCtx* timeoutTask;
    RemoteTaksMsgType remoteTaskType;
} RemoteTaksMsg;

typedef struct RemoteTaskResult {
    union {
        Record *res;
        MRError *error;
    };
    ReplyType replyType;
} RemoteTaskResult;

typedef struct RunOnKeyMsg {
    RemoteTaksMsg remoteTaskBase;
    size_t slot;
    void (*onDone)(void *pd, Record* result);
    void (*onError)(void *pd, MRError* err);
    void *pd;
    RemoteTaskResult remoteTaskRes;
} RunOnKeyMsg;

typedef struct RunOnShardsMsg {
    RemoteTaksMsg remoteTaskBase;
    void (*onDone)(void *pd, Record** result, size_t nResults, MRError** errs, size_t nErrs);
    void *pd;
    ReplyType replyType;
    void* args;
    Record* r;
    ARR(Record*) results;
    ARR(MRError*) errs;
    size_t expectedNResults;
    size_t nResultsArrived;
    StepDefinition* sd;
} RunOnShardsMsg;

/* Run on thread pool */
static void MR_RemoteTaskOnShardsDoneInternal(void* pd) {
    RunOnShardsMsg *msg = pd;
    msg->onDone(msg->pd, msg->results, array_len(msg->results), msg->errs, array_len(msg->errs));

    array_free(msg->results);
    array_free(msg->errs);
    MR_FREE(msg);
}

/* Run on thread pool */
static void MR_RemoteTaskOnKeyDoneInternal(void* pd) {
    RunOnKeyMsg *msg = pd;

    if (msg->remoteTaskRes.replyType == ReplyType_OK) {
        msg->onDone(msg->pd, msg->remoteTaskRes.res);
    } else {
        msg->onError(msg->pd, msg->remoteTaskRes.error);
    }

    MR_FREE(msg);
}

/* Run on the event loop */
static void MR_RemoteTaskDoneProcessesResult(const char *id, RemoteTaskResult remoteTaskRes) {
    RemoteTaksMsg *msgBase = mr_dictFetchValue(mrCtx.remoteDict, id);
    if (!msgBase) {
        RedisModule_Log(NULL, "warning", "Got a remote task done on none existing ID %.*s", REDISMODULE_NODE_ID_LEN, id);
        return;
    }

    if (msgBase->remoteTaskType == RemoteTaksMsgType_OnKey) {
        RunOnKeyMsg *msg = (RunOnKeyMsg*)msgBase;
        msg->remoteTaskRes = remoteTaskRes;

        if (msg->remoteTaskBase.timeoutTask) {
            MR_EventLoopDelayTaskCancel(msg->remoteTaskBase.timeoutTask);
            msg->remoteTaskBase.timeoutTask = NULL;
        }

        /* Remove msg from remoteDict, we will be done with it once we fire the done callback */
        mr_dictDelete(mrCtx.remoteDict, msgBase->id);

        /* Run the callback on the thread pool */
        mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskOnKeyDoneInternal, msg);
    } else {
        RedisModule_Assert(msgBase->remoteTaskType == RemoteTaksMsgType_OnAllShards);
        RunOnShardsMsg *msg = (RunOnShardsMsg*)msgBase;
        if (remoteTaskRes.replyType == ReplyType_OK) {
            msg->results = array_append(msg->results, remoteTaskRes.res);
        } else {
            msg->errs = array_append(msg->errs, remoteTaskRes.error);
        }
        ++msg->nResultsArrived;
        if (msg->nResultsArrived == msg->expectedNResults) {
            /* Got all the results */

            if (msg->remoteTaskBase.timeoutTask) {
                MR_EventLoopDelayTaskCancel(msg->remoteTaskBase.timeoutTask);
                msg->remoteTaskBase.timeoutTask = NULL;
            }

            /* Remove msg from remoteDict, we will be done with it once we fire the done callback */
            mr_dictDelete(mrCtx.remoteDict, msgBase->id);

            /* Run the callback on the thread pool */
            mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskOnShardsDoneInternal, msg);
        }
    }
}

/* Run on the event loop */
static void MR_RemoteTaskDone(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    size_t dataSize;
    const char* data = RedisModule_StringPtrLen(payload, &dataSize);
    mr_Buffer buff = {
            .buff = (char*)data,
            .size = dataSize,
            .cap = dataSize,
    };
    mr_BufferReader buffReader;
    mr_BufferReaderInit(&buffReader, &buff);

    size_t idLen;
    const char *id = mr_BufferReaderReadBuff(&buffReader, &idLen, NULL);
    RedisModule_Assert(idLen == ID_LEN);

    RemoteTaskResult remoteTaskRes;

    if (mr_BufferReaderReadLongLong(&buffReader, NULL)) {
        remoteTaskRes.res = MR_RecordDeSerialize(&buffReader);
        remoteTaskRes.replyType = ReplyType_OK;
    } else {
        const char* errMsg = mr_BufferReaderReadString(&buffReader, NULL);
        remoteTaskRes.error = MR_ErrorCreate(errMsg, strlen(errMsg));
        remoteTaskRes.replyType = ReplyType_ERROR;
    }

    MR_RemoteTaskDoneProcessesResult(id, remoteTaskRes);
}

static void MR_RemoteTaskErrorOnRemote(void *pd, MRError *error) {
    RunOnKeyReplyMsg *replyMsg = pd;

    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);

    /* write id */
    mr_BufferWriterWriteBuff(&buffWriter, replyMsg->id, ID_LEN);

    mr_BufferWriterWriteLongLong(&buffWriter, 0); /* mean failure */

    mr_BufferWriterWriteString(&buffWriter, error->msg);

    MR_ClusterSendMsg(replyMsg->sender, REMOTE_TASK_DONE_FUNCTION_ID, buff.buff, buff.size);

    MR_ErrorFree(error);
    MR_FREE(replyMsg->id);
    MR_FREE(replyMsg->sender);
    MR_FREE(replyMsg);
}

static void MR_RemoteTaskDoneOnRemote(void *pd, Record *res) {
    RunOnKeyReplyMsg *replyMsg = pd;

    MRError* error = NULL;
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);

    /* write id */
    mr_BufferWriterWriteBuff(&buffWriter, replyMsg->id, ID_LEN);

    mr_BufferWriterWriteLongLong(&buffWriter, 1); /* mean success */

    MR_RecordSerialize(res, &buffWriter);
    /* todo: handler serialization failure */

    MR_ClusterSendMsg(replyMsg->sender, REMOTE_TASK_DONE_FUNCTION_ID, buff.buff, buff.size);

    MR_RecordFree(res);
    MR_FREE(replyMsg->id);
    MR_FREE(replyMsg->sender);
    MR_FREE(replyMsg);
}

/* Runs on thread pool */
static void MR_RemoteTaskInternal(void* pd) {
    RedisModuleString* payload = pd;
    size_t dataSize;
    const char* data = RedisModule_StringPtrLen(payload, &dataSize);
    mr_Buffer buff = {
            .buff = (char*)data,
            .size = dataSize,
            .cap = dataSize,
    };
    mr_BufferReader buffReader;
    mr_BufferReaderInit(&buffReader, &buff);

    /* Read sender id */
    const char *sender = mr_BufferReaderReadString(&buffReader, NULL);

    size_t idLen;
    const char *id = mr_BufferReaderReadBuff(&buffReader, &idLen, NULL);
    RedisModule_Assert(idLen == ID_LEN);

    const char *remoteTaskName = mr_BufferReaderReadString(&buffReader, NULL);
    StepDefinition* sd = mr_dictFetchValue(mrCtx.remoteTasksDict, remoteTaskName);
    RedisModule_Assert(sd);

    MRError* error = NULL;
    void *args = sd->type->deserialize(&buffReader, &error);
    /* todo: handler serialization failure */

    Record *r = MR_RecordDeSerialize(&buffReader);
    /* todo: handler serialization failure */

    RunOnKeyReplyMsg *replyMsg = MR_ALLOC(sizeof(*replyMsg));
    replyMsg->sender = MR_STRDUP(sender);
    replyMsg->id = MR_ALLOC(idLen);
    memcpy(replyMsg->id, id, idLen);

    ((RemoteTask)sd->callback)(r, args, MR_RemoteTaskDoneOnRemote, MR_RemoteTaskErrorOnRemote, replyMsg);

    /* We must take the Redis GIL to free the payload,
     * RedisModuleString refcount are not thread safe.
     * We better do it here and stuck on of the threads
     * in the thread pool then do it on the event loop.
     * Possible optimization would be to batch multiple
     * payloads into one GIL locking */
    RedisModule_ThreadSafeContextLock(mr_staticCtx);
    RedisModule_FreeString(NULL, payload);
    RedisModule_ThreadSafeContextUnlock(mr_staticCtx);
}

/* Runs on the event loop */
static void MR_RemoteTask(RedisModuleCtx *ctx, const char *sender_id, uint8_t type, RedisModuleString* payload) {
    /* We can directly move the job to the thread pool for deserialization and execution */
    mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskInternal, RedisModule_HoldString(NULL, payload));
}

/* Invoked on the event look */
static void MR_RemoteTaskOnKeyTimeoutOut(void* ctx) {
    static const char TIMEOUT_TEXT[] = "Remote task timeout";
    RunOnKeyMsg *msg = ctx;
    msg->remoteTaskBase.timeoutTask = NULL;

    msg->remoteTaskRes.error = MR_ErrorCreate(TIMEOUT_TEXT, sizeof(TIMEOUT_TEXT) - 1);
    msg->remoteTaskRes.replyType = ReplyType_ERROR;

    /* Remove msg from remoteDict, we will be done with it once we fire the done callback */
    int res = mr_dictDelete(mrCtx.remoteDict, msg->remoteTaskBase.id);
    RedisModule_Assert(res == DICT_OK);

    /* Run the callback on the thread pool */
    mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskOnKeyDoneInternal, msg);
}

/* Invoked on the event look */
static void MR_RunOnKeyInternal(void* ctx) {
    RunOnKeyMsg *msg = ctx;

    /* add the task to the remote mappers dictionary */
    mr_dictAdd(mrCtx.remoteDict, msg->remoteTaskBase.id, msg);

    /* send the message to the shard */
    MR_ClusterSendMsgBySlot(msg->slot, REMOTE_TASK_FUNCTION_ID, msg->remoteTaskBase.msg, msg->remoteTaskBase.msgLen);

    /* ownership on the message was moved to MR_ClusterSendMsgBySlot function */
    msg->remoteTaskBase.msg = NULL;
    msg->remoteTaskBase.msgLen = 0;

    if (msg->remoteTaskBase.timeout != SIZE_MAX) {
        msg->remoteTaskBase.timeoutTask = MR_EventLoopAddTaskWithDelay(MR_RemoteTaskOnKeyTimeoutOut, msg, msg->remoteTaskBase.timeout);
    }
}

LIBMR_API void MR_RunOnKey(const char* keyName,
                           size_t keyNameSize,
                           const char* remoteTaskName,
                           void* args,
                           Record* r,
                           MR_RunOnKey_OnDone onDone,
                           MR_RunOnKey_OnError onError,
                           void *pd,
                           size_t timeout)
{
    StepDefinition* sd = mr_dictFetchValue(mrCtx.remoteTasksDict, remoteTaskName);
    RedisModule_Assert(sd);
    size_t slot = MR_ClusterGetSlotByKey(keyName, keyNameSize);
    if (!MR_ClusterIsInClusterMode() || MR_ClusterIsMySlot(slot)) {
        ((RemoteTask)sd->callback)(r, args, onDone, onError, pd);
        return;
    }

    RunOnKeyMsg *msg = MR_ALLOC(sizeof(*msg));
    msg->slot = slot;
    msg->onDone = onDone;
    msg->onError = onError;
    msg->pd = pd;
    msg->remoteTaskBase.timeout = timeout;
    msg->remoteTaskBase.timeoutTask = NULL;
    msg->remoteTaskBase.remoteTaskType = RemoteTaksMsgType_OnKey;
    /* Set id */
    size_t id = __atomic_add_fetch(&mrCtx.lastExecutionId, 1, __ATOMIC_RELAXED);
    SetId(msg->remoteTaskBase.id, msg->remoteTaskBase.idStr, id);

    MRError* error = NULL;
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);
    /* write sender */
    mr_BufferWriterWriteString(&buffWriter, MR_ClusterGetMyId());
    /* write id */
    mr_BufferWriterWriteBuff(&buffWriter, msg->remoteTaskBase.id, ID_LEN);
    /* mapped name to invoke */
    mr_BufferWriterWriteString(&buffWriter, remoteTaskName);
    /* Serialize args */
    sd->type->serialize(&buffWriter, args, &error);
    sd->type->free(args);
    /* todo: handler serialization failure */
    /* serialize the record */
    MR_RecordSerialize(r, &buffWriter);
    MR_RecordFree(r);

    msg->remoteTaskBase.msg = buff.buff;
    msg->remoteTaskBase.msgLen = buff.size;

    MR_EventLoopAddTask(MR_RunOnKeyInternal, msg);
}

typedef struct RemoteTaskLocalRun{
    char id[ID_LEN];
    StepDefinition* sd;
    void* args;
    Record* r;
    RemoteTaskResult result;
} RemoteTaskLocalRun;


static void MR_RemoteTaskDoneOnLocalEVLoop(void* ctx) {
    RemoteTaskLocalRun* localRun = ctx;

    MR_RemoteTaskDoneProcessesResult(localRun->id, localRun->result);

    MR_FREE(localRun);
}

static void MR_RemoteTaskErrorOnLocal(void *pd, MRError *error) {
    RemoteTaskLocalRun* localRun = pd;
    localRun->result.replyType = ReplyType_ERROR;
    localRun->result.error = error;
    MR_EventLoopAddTask(MR_RemoteTaskDoneOnLocalEVLoop, localRun);
}

static void MR_RemoteTaskDoneOnLocal(void *pd, Record *res) {
    RemoteTaskLocalRun* localRun = pd;
    localRun->result.replyType = ReplyType_OK;
    localRun->result.res = res;
    MR_EventLoopAddTask(MR_RemoteTaskDoneOnLocalEVLoop, localRun);
}

static void MR_RemoteTaskRunOnLocal(void *pd) {
    RemoteTaskLocalRun* localRun = pd;
    void* args = localRun->args;
    Record* r = localRun->r;
    localRun->args = NULL;
    localRun->r = NULL;
    ((RemoteTask)localRun->sd->callback)(r, args, MR_RemoteTaskDoneOnLocal, MR_RemoteTaskErrorOnLocal, localRun);
}

/* Invoked on the event look */
static void MR_RemoteTaskOnAllShardsTimeoutOut(void* ctx) {
    RunOnShardsMsg *msg = ctx;
    msg->remoteTaskBase.timeoutTask = NULL;

    msg->errs = array_append(msg->errs, MR_ErrorCreate("Timeout", 7));

    /* Remove msg from remoteDict, we will be done with it once we fire the done callback */
    int res = mr_dictDelete(mrCtx.remoteDict, msg->remoteTaskBase.id);
    RedisModule_Assert(res == DICT_OK);

    /* Run the callback on the thread pool */
    mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskOnShardsDoneInternal, msg);
}

/* Invoked on the event loop */
static void MR_RunOnAllShardsInternal(void* ctx) {
    RunOnShardsMsg *msg = ctx;

    /* add the task to the remote mappers dictionary */
    mr_dictAdd(mrCtx.remoteDict, msg->remoteTaskBase.id, msg);

    if (MR_ClusterIsInClusterMode()) {
        /* send the message to the shard */
        MR_ClusterSendMsg(NULL, REMOTE_TASK_FUNCTION_ID, msg->remoteTaskBase.msg, msg->remoteTaskBase.msgLen);
    } else {
        MR_FREE(msg->remoteTaskBase.msg);
    }

    /* ownership on the message was moved to MR_ClusterSendMsgBySlot function */
    msg->remoteTaskBase.msg = NULL;
    msg->remoteTaskBase.msgLen = 0;

    /* Create local run */
    RemoteTaskLocalRun* localRun = MR_ALLOC(sizeof(*localRun));
    memcpy(localRun->id, msg->remoteTaskBase.id, ID_LEN);
    localRun->args = msg->args;
    localRun->r = msg->r;
    localRun->sd = msg->sd;
    mr_thpool_add_work(mrCtx.executionsThreadPool, MR_RemoteTaskRunOnLocal, localRun);
    msg->args = NULL;
    msg->r = NULL;

    if (msg->remoteTaskBase.timeout != SIZE_MAX) {
        msg->remoteTaskBase.timeoutTask = MR_EventLoopAddTaskWithDelay(MR_RemoteTaskOnAllShardsTimeoutOut, msg, msg->remoteTaskBase.timeout);
    }
}

LIBMR_API void MR_RunOnAllShards(const char* remoteTaskName,
                                 void* args,
                                 Record* r,
                                 MR_RunOnShards_OnDone onDone,
                                 void *pd,
                                 size_t timeout) {
    StepDefinition* sd = mr_dictFetchValue(mrCtx.remoteTasksDict, remoteTaskName);
    RedisModule_Assert(sd);

    RunOnShardsMsg *msg = MR_ALLOC(sizeof(*msg));
    msg->onDone = onDone;
    msg->pd = pd;
    msg->remoteTaskBase.timeout = timeout;
    msg->remoteTaskBase.timeoutTask = NULL;
    msg->remoteTaskBase.remoteTaskType = RemoteTaksMsgType_OnAllShards;
    msg->args = args;
    msg->r = r;
    msg->expectedNResults = MR_ClusterGetSize();
    msg->nResultsArrived = 0;
    msg->results = array_new(Record*, 10);
    msg->errs = array_new(MRError*, 10);
    msg->sd = sd;

            /* Set id */
    size_t id = __atomic_add_fetch(&mrCtx.lastExecutionId, 1, __ATOMIC_RELAXED);
    SetId(msg->remoteTaskBase.id, msg->remoteTaskBase.idStr, id);

    MRError* error = NULL;
    mr_Buffer buff;
    mr_BufferInitialize(&buff);
    mr_BufferWriter buffWriter;
    mr_BufferWriterInit(&buffWriter, &buff);
    /* write sender */
    mr_BufferWriterWriteString(&buffWriter, MR_ClusterGetMyId());
    /* write id */
    mr_BufferWriterWriteBuff(&buffWriter, msg->remoteTaskBase.id, ID_LEN);
    /* mapped name to invoke */
    mr_BufferWriterWriteString(&buffWriter, remoteTaskName);
    /* Serialize args */
    sd->type->serialize(&buffWriter, args, &error);
    /* todo: handler serialization failure */
    /* serialize the record */
    MR_RecordSerialize(r, &buffWriter);

    msg->remoteTaskBase.msg = buff.buff;
    msg->remoteTaskBase.msgLen = buff.size;

    MR_EventLoopAddTask(MR_RunOnAllShardsInternal, msg);
}

void MR_SerializationCtxReaderRewind(ReaderSerializationCtx* sctx) {
    mr_BufferReaderRewind(sctx);
}
void MR_SerializationCtxWriterRewind(WriteSerializationCtx* sctx) {
    mr_BufferWriterRewind(sctx);
}
bool MR_SerializationCtxReaderIsDepleted(ReaderSerializationCtx* sctx) {
    return mr_BufferReaderIsDepleted(sctx);
}
bool MR_SerializationCtxWriterIsDepleted(WriteSerializationCtx* sctx) {
    return mr_BufferWriterIsDepleted(sctx);
}
