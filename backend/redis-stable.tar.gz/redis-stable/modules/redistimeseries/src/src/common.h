#pragma once

#include <stdlib.h>
#include <string.h>
#include "RedisModulesSDK/redismodule.h"

// Non-aborting allocation: RedisModule_Calloc aborts the process on OOM (VDP-4658),
// so prefer RedisModule_Try* (returns NULL). Falls back to the default allocator
// when Try* isn't bound (libc in unit builds; the aborting RedisModule_Calloc/Alloc
// in the module build, where Try* is always bound on Redis >= 7.0).
#define rts_try_calloc(count, size)                                                                \
    (RedisModule_TryCalloc ? RedisModule_TryCalloc((count), (size)) : calloc((count), (size)))
#define rts_try_alloc(size) (RedisModule_TryAlloc ? RedisModule_TryAlloc((size)) : malloc((size)))

#define RTS_ERR "ERR"
#define RTS_NOPERM "NOPERM"
#define RTS_ReplyError(ctx, err_type, msg) RedisModule_ReplyWithError(ctx, err_type " " msg)
#define RTS_ReplyGeneralError(ctx, msg) RTS_ReplyError(ctx, RTS_ERR, msg)
#define RTS_ReplyPermissionError(ctx, msg) RTS_ReplyError(ctx, RTS_NOPERM, msg)
#define RTS_ReplyKeyPermissionsError(ctx)                                                          \
    RTS_ReplyPermissionError(ctx,                                                                  \
                             "TSDB: current user doesn't have read permission to one or more "     \
                             "keys that match the specified filter")

static inline int stringEqualsC(const RedisModuleString *s1, const char *s2) {
    size_t len;
    const char *s1Str = RedisModule_StringPtrLen(s1, &len);
    return len == strlen(s2) && strncmp(s1Str, s2, len) == 0;
}

enum
{
    DefragStatus_Finished = 0,
    DefragStatus_Paused = 1,
};

static inline void *defragPtr(RedisModuleDefragCtx *ctx, void *ptr) {
    if (ptr == NULL) {
        return NULL;
    }
    return RedisModule_DefragAlloc(ctx, ptr) ?: ptr;
}
static inline RedisModuleString *defragString(RedisModuleDefragCtx *ctx, RedisModuleString *str) {
    if (str == NULL) {
        return NULL;
    }
    return RedisModule_DefragRedisModuleString(ctx, str) ?: str;
}
static inline RedisModuleDict *defragDict(RedisModuleDefragCtx *ctx,
                                          RedisModuleDict *dict,
                                          RedisModuleDefragDictValueCallback valueCB,
                                          RedisModuleString **seekTo) {
    if (dict == NULL) {
        return NULL;
    }
    return RedisModule_DefragRedisModuleDict(ctx, dict, valueCB, seekTo) ?: dict;
}

int NotifyCallback(RedisModuleCtx *ctx, int type, const char *event, RedisModuleString *key);

static inline void lazyModuleInitialize(RedisModuleCtx *ctx) {
    static int lazy_initialized = 0;
    if (!lazy_initialized) {
        RedisModule_SubscribeToKeyspaceEvents(
            ctx,
            REDISMODULE_NOTIFY_GENERIC | REDISMODULE_NOTIFY_TYPE_CHANGED |
                REDISMODULE_NOTIFY_EVICTED | REDISMODULE_NOTIFY_EXPIRED |
                REDISMODULE_NOTIFY_LOADED | REDISMODULE_NOTIFY_KEY_TRIMMED |
                REDISMODULE_NOTIFY_TRIMMED, // Only during redis enterprise sharding
            NotifyCallback);
        lazy_initialized = 1;
    }
}

#if (defined(DEBUG) || defined(_DEBUG)) && !defined(NDEBUG)
#include "readies/cetara/diag/gdb.h"
#endif
