/*
 * Copyright (c) 2006-Present, Redis Ltd.
 * All rights reserved.
 *
 * Licensed under your choice of (a) the Redis Source Available License 2.0
 * (RSALv2); or (b) the Server Side Public License v1 (SSPLv1); or (c) the
 * GNU Affero General Public License v3 (AGPLv3).
 */
#include "compaction.h"

#include "load_io_error_macros.h"
#include "rdb.h"

#include "rmutil/alloc.h"
#include "compactions/compaction_common.h"
#include "compactions/compaction_avx512f.h"
#include "compactions/compaction_avx2.h"
#include "utils/arch_features.h"

#include <ctype.h>
#include <float.h>
#include <math.h> // sqrt
#include <string.h>
#include <assert.h>

#if defined(_DEBUG) && defined(_VALGRIND)
#include "valgrind/valgrind.h"
#endif

typedef struct FirstValueContext
{
    double value;
    char isResetted;
    timestamp_t ts; /* in-memory only; tracks oldest sample seen */
} FirstValueContext;

typedef struct SingleValueContext
{
    double value;
    timestamp_t ts;    /* in-memory only; tracks newest sample seen */
    bool fresh_bucket; /* in-memory only; lets reverse-mode reset across buckets without losing LOCF
                        */
} SingleValueContext;

typedef struct AvgContext
{
    double val;
    double cnt;
    bool isOverflow;
} AvgContext;

typedef struct TwaContext
{
    double res;
    timestamp_t prevTS;
    double prevValue;
    timestamp_t bucketStartTS;
    timestamp_t bucketEndTS;
    timestamp_t first_ts;
    timestamp_t last_ts;
    bool is_first_bucket;
    bool reverse;
    int64_t iteration;
} TwaContext;

typedef struct StdContext
{
    double sum;
    double sum_2; // sum of (values^2)
    uint64_t cnt;
} StdContext;

void finalize_empty_with_NAN(__unused void *contextPtr, double *value) {
    *value = NAN;
}

void finalize_empty_with_ZERO(__unused void *contextPtr, double *value) {
    *value = 0;
}

void finalize_empty_last_value(void *contextPtr, double *value) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    *value = context->value;
}

void *SingleValueCreateContext(__unused bool reverse) {
    SingleValueContext *context = (SingleValueContext *)malloc(sizeof(SingleValueContext));
    context->value = 0;
    context->ts = 0;
    context->fresh_bucket = true;
    return context;
}

void *SingleValueCloneContext(void *contextPtr) {
    SingleValueContext *buf = (SingleValueContext *)malloc(sizeof(SingleValueContext));
    memcpy(buf, contextPtr, sizeof(SingleValueContext));
    return buf;
}

void SingleValueReset(void *contextPtr) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    context->value = 0;
    context->ts = 0;
    context->fresh_bucket = true;
}

void *LastValueCreateContext(__unused bool reverse) {
    SingleValueContext *context = malloc(sizeof *context);
    context->value = NAN;
    context->ts = 0;
    context->fresh_bucket = true;
    return context;
}

void LastValueReset(void *contextPtr) {
    /* Don't touch value — EMPTY+LAST wants LOCF carry-over. Mark bucket boundary so the next
     * appendValue accepts a fresh sample regardless of stored ts (which may linger from a newer
     * bucket processed earlier when iterating in reverse). */
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    context->fresh_bucket = true;
}

/* LOCF seed for reverse-mode empty-bucket emission: the empty gap inherits the value of the
 * older (chronologically previous) sample. In reverse iteration that sample hasn't been seen
 * yet by the aggregator, so we plant it directly. Sets both value and ts so the context stays
 * internally consistent — otherwise the stale ts from a newer bucket would linger. */
void LastValueSeedLocf(void *contextPtr, double value, timestamp_t ts) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    context->value = value;
    context->ts = ts;
}

/* True when a TS_AGG_LAST context holds no carry-over value yet (created but no sample appended).
 * Used to decide whether a forward empty gap needs LOCF seeding from the older neighbor.
 * NaN is a reliable "unseeded" sentinel here: aggLast.isValueValid == nonNaNValueValid, so a NaN
 * sample is never appended, hence context->value is NaN iff no sample has ever been observed. */
bool LastValueIsUnseeded(void *contextPtr) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    return isnan(context->value);
}

int SingleValueFinalize(void *contextPtr, double *val) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    *val = context->value;
    return TSDB_OK;
}

void SingleValueWriteContext(void *contextPtr, RedisModuleIO *io) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    RedisModule_SaveDouble(io, context->value);
}

int SingleValueReadContext(void *contextPtr, RedisModuleIO *io, int encver) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    bool err = false;
    context->value = LoadDouble_IOError(io, err, TSDB_ERROR);
    if (encver >= TS_IS_RESSETED_DUP_POLICY_RDB_VER && encver < TS_LAST_AGGREGATION_EMPTY) {
        // In old rdbs there was is_resetted flag
        LoadUnsigned_IOError(io, err, TSDB_ERROR);
    }
    return TSDB_OK;
}

void *FirstValueCreateContext(__unused bool reverse) {
    FirstValueContext *context = (FirstValueContext *)malloc(sizeof(FirstValueContext));
    context->value = 0;
    context->isResetted = true;
    context->ts = 0;
    return context;
}

void *FirstValueCloneContext(void *contextPtr) {
    FirstValueContext *buf = (FirstValueContext *)malloc(sizeof(FirstValueContext));
    memcpy(buf, contextPtr, sizeof(FirstValueContext));
    return buf;
}

void FirstValueReset(void *contextPtr) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    context->value = 0;
    context->isResetted = true;
    context->ts = 0;
}

int FirstValueFinalize(void *contextPtr, double *val) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    *val = context->value;
    return TSDB_OK;
}

void FirstValueWriteContext(void *contextPtr, RedisModuleIO *io) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    RedisModule_SaveDouble(io, context->value);
    RedisModule_SaveUnsigned(io, context->isResetted);
}

int FirstValueReadContext(void *contextPtr, RedisModuleIO *io, int encver) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    bool err = false;
    context->value = LoadDouble_IOError(io, err, TSDB_ERROR);
    if (encver >= TS_IS_RESSETED_DUP_POLICY_RDB_VER) {
        context->isResetted = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    }
    return TSDB_OK;
}

static inline void _AvgInitContext(AvgContext *context) {
    context->cnt = 0;
    context->val = 0;
    context->isOverflow = false;
}

void *AvgCreateContext(__unused bool reverse) {
    AvgContext *context = (AvgContext *)malloc(sizeof(AvgContext));
    _AvgInitContext(context);
    return context;
}

void *AvgCloneContext(void *contextPtr) {
    AvgContext *buf = (AvgContext *)malloc(sizeof(AvgContext));
    memcpy(buf, contextPtr, sizeof(AvgContext));
    return buf;
}

// Except valgrind it's equivalent to sizeof(long double) > 8
#if !defined(_DEBUG) && !defined(_VALGRIND)
bool hasLongDouble = sizeof(long double) > 8;
#else
bool hasLongDouble = false;
#endif

void AvgAddValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    AvgContext *context = (AvgContext *)contextPtr;
    context->cnt++;

    // Test for overflow
    if (unlikely(((context->val < 0.0) == (value < 0.0) &&
                  (fabs(context->val) > (DBL_MAX - fabs(value)))) ||
                 context->isOverflow)) {
        // calculating: avg(t+1) = t*avg(t)/(t+1) + val/(t+1)

        long double ld_val = context->val;
        long double ld_value = value;
        if (likely(hasLongDouble)) { // better accuracy
            ld_val /= context->cnt;
            if (context->isOverflow) {
                ld_val *= (long double)(context->cnt - 1);
            }
        } else {
            if (context->isOverflow) {
                ld_val *= ((long double)(context->cnt - 1) / context->cnt);
            } else {
                ld_val /= context->cnt;
            }
        }
        ld_val += (ld_value / (long double)context->cnt);
        context->val = ld_val;
        context->isOverflow = true;
    } else { // No Overflow
        context->val += value;
    }
}

int AvgFinalize(void *contextPtr, double *value) {
    AvgContext *context = (AvgContext *)contextPtr;
    if (unlikely(context->cnt == 0)) {
        _log_if(context->cnt == 0, "AvgFinalize: context->cnt is 0");
        return TSDB_ERROR;
    }

    if (unlikely(context->isOverflow)) {
        *value = context->val;
    } else {
        *value = context->val / context->cnt;
    }
    return TSDB_OK;
}

void AvgReset(void *contextPtr) {
    _AvgInitContext(contextPtr);
}

void AvgWriteContext(void *contextPtr, RedisModuleIO *io) {
    AvgContext *context = (AvgContext *)contextPtr;
    RedisModule_SaveDouble(io, context->val);
    RedisModule_SaveDouble(io, context->cnt);
    RedisModule_SaveUnsigned(io, context->isOverflow);
}

int AvgReadContext(void *contextPtr, RedisModuleIO *io, int encver) {
    AvgContext *context = (AvgContext *)contextPtr;
    bool err = false;
    context->val = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->cnt = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->isOverflow = false;
    if (encver >= TS_OVERFLOW_RDB_VER) {
        context->isOverflow = !!(LoadUnsigned_IOError(io, err, TSDB_ERROR));
    }
    return TSDB_OK;
}

static inline void _TwainitContext(TwaContext *context, bool reverse) {
    context->res = 0;
    context->prevTS = DC;        // arbitrary value
    context->prevValue = DC;     // arbitrary value
    context->bucketStartTS = DC; // arbitrary value
    context->bucketEndTS = DC;   // arbitrary value
    context->first_ts = DC;
    context->last_ts = DC;
    context->is_first_bucket = true;
    context->iteration = 0;
    context->reverse = reverse;
}

void *TwaCloneContext(void *contextPtr) {
    TwaContext *buf = (TwaContext *)malloc(sizeof(TwaContext));
    memcpy(buf, contextPtr, sizeof(TwaContext));
    return buf;
}

void *TwaCreateContext(bool reverse) {
    TwaContext *context = (TwaContext *)malloc(sizeof(TwaContext));
    _TwainitContext(context, reverse);
    return context;
}

static inline void _update_twaContext(TwaContext *wcontext,
                                      const double *value,
                                      const timestamp_t *ts) {
    wcontext->prevValue = *value;
    wcontext->prevTS = *ts;
}

void TwaAddBucketParams(void *contextPtr, timestamp_t bucketStartTS, timestamp_t bucketEndTS) {
    TwaContext *context = (TwaContext *)contextPtr;
    if (context->reverse) {
        __SWAP(bucketStartTS, bucketEndTS);
    }
    context->bucketStartTS = bucketStartTS;
    context->bucketEndTS = bucketEndTS;
}

void TwaAddPrevBucketLastSample(void *contextPtr, double value, timestamp_t ts) {
    TwaContext *wcontext = (TwaContext *)contextPtr;
    _update_twaContext(wcontext, &value, &ts);
    wcontext->is_first_bucket = false;
}

void TwaAddValue(void *contextPtr, double value, timestamp_t ts) {
    TwaContext *context = (TwaContext *)contextPtr;
    int64_t *iter = &context->iteration;
    timestamp_t t1 = context->prevTS, t2 = ts;
    double v1 = context->prevValue, v2 = value;
    if (context->reverse) {
        __SWAP(t1, t2);
        __SWAP(v1, v2);
    }
    const double delta_time = t2 - t1;
    const double delta_val = v2 - v1;
    const bool *is_first_bucket = &context->is_first_bucket;
    const timestamp_t ta = context->bucketStartTS;

    if ((*iter) == 0) { // First sample in bucket
        if (!(*is_first_bucket)) {
            context->first_ts = ta;
            double vab = v1 + ((double)((ta - t1) * delta_val)) / delta_time;
            if (!context->reverse) {
                context->res += ((vab + v2) * (t2 - ta)) / 2.0;
            } else {
                context->res += ((vab + v1) * (ta - t1)) / 2.0;
            }
        } else {
            // else: cur sample is the first in the series, so just store it
            context->first_ts = ts;
        }
    } else {
        context->res += ((v1 + v2) * (t2 - t1)) / 2.0;
    }

    // store this sample for next iteration
    context->last_ts = context->prevTS = ts;
    context->prevValue = value;
    ++(*iter);
}

void TwaAddNextBucketFirstSample(void *contextPtr, double value, timestamp_t ts) {
    TwaContext *context = (TwaContext *)contextPtr;
    timestamp_t t1 = context->prevTS, t2 = ts;
    double v1 = context->prevValue, v2 = value;
    if (context->reverse) {
        __SWAP(t1, t2);
        __SWAP(v1, v2);
    }
    const double delta_time = t2 - t1;
    const double delta_val = v2 - v1;
    const timestamp_t tb = context->bucketEndTS;

    double vab = v1 + ((double)((tb - t1) * delta_val)) / delta_time;
    if (!context->reverse) {
        context->res += ((vab + v1) * (tb - t1)) / 2.0;
    } else {
        context->res += ((vab + v2) * (t2 - tb)) / 2.0;
    }

    context->last_ts = tb;
}

int TwaFinalize(void *contextPtr, double *value) {
    TwaContext *context = (TwaContext *)contextPtr;
    if (context->last_ts == context->first_ts) {
        // Or the size of the bucket is 0 with one sample in it,
        // or there is only one sample in the series.
        *value = context->prevValue;
    } else {
        *value = context->res / llabs((int64_t)(context->last_ts - context->first_ts));
    }
    return TSDB_OK;
}

void TwaGetLastSample(void *contextPtr, Sample *sample) {
    TwaContext *wcontext = (TwaContext *)contextPtr;
    sample->timestamp = wcontext->prevTS;
    sample->value = wcontext->prevValue;
}

void TwaReset(void *contextPtr) {
    TwaContext *wcontext = (TwaContext *)contextPtr;
    _TwainitContext(contextPtr, wcontext->reverse);
}

void TwaWriteContext(void *contextPtr, RedisModuleIO *io) {
    TwaContext *context = (TwaContext *)contextPtr;
    RedisModule_SaveDouble(io, context->res);
    RedisModule_SaveUnsigned(io, context->prevTS);
    RedisModule_SaveDouble(io, context->prevValue);
    RedisModule_SaveUnsigned(io, context->bucketStartTS);
    RedisModule_SaveUnsigned(io, context->bucketEndTS);
    RedisModule_SaveUnsigned(io, context->first_ts);
    RedisModule_SaveUnsigned(io, context->last_ts);
    RedisModule_SaveUnsigned(io, context->is_first_bucket);
    RedisModule_SaveUnsigned(io, context->iteration);
    RedisModule_SaveUnsigned(io, context->reverse);
}

int TwaReadContext(void *contextPtr, RedisModuleIO *io, int encver) {
    TwaContext *context = (TwaContext *)contextPtr;
    bool err = false;
    context->res = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->prevTS = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->prevValue = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->bucketStartTS = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->bucketEndTS = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->first_ts = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->last_ts = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->is_first_bucket = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->iteration = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    context->reverse = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    return TSDB_OK;
}

void *StdCreateContext(__unused bool reverse) {
    StdContext *context = (StdContext *)malloc(sizeof(StdContext));
    context->cnt = 0;
    context->sum = 0;
    context->sum_2 = 0;
    return context;
}

void *StdCloneContext(void *contextPtr) {
    StdContext *buf = (StdContext *)malloc(sizeof(StdContext));
    memcpy(buf, contextPtr, sizeof(StdContext));
    return buf;
}

void StdAddValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    StdContext *context = (StdContext *)contextPtr;
    ++context->cnt;
    context->sum += value;
    context->sum_2 += value * value;
}

static inline double variance(double sum, double sum_2, double count) {
    if (count == 0) {
        return 0;
    }

    /*  var(X) = sum((x_i - E[X])^2)
     *  = sum(x_i^2) - 2 * sum(x_i) * E[X] + E^2[X] */
    return (sum_2 - 2 * sum * sum / count + pow(sum / count, 2) * count) / count;
}

int VarPopulationFinalize(void *contextPtr, double *value) {
    StdContext *context = (StdContext *)contextPtr;
    uint64_t count = context->cnt;
    if (unlikely(count == 0)) {
        *value = 0;
        return TSDB_ERROR;
    }
    *value = variance(context->sum, context->sum_2, count);
    return TSDB_OK;
}

int VarSamplesFinalize(void *contextPtr, double *value) {
    StdContext *context = (StdContext *)contextPtr;
    uint64_t count = context->cnt;
    if (unlikely(count == 0)) {
        *value = 0;
        return TSDB_ERROR;
    }
    if (count == 1) {
        *value = 0;
    } else {
        *value = variance(context->sum, context->sum_2, count) * count / (count - 1);
    }
    return TSDB_OK;
}

int StdPopulationFinalize(void *contextPtr, double *value) {
    double val;
    int ret = VarPopulationFinalize(contextPtr, &val);
    *value = sqrt(val);
    return ret;
}

int StdSamplesFinalize(void *contextPtr, double *value) {
    double val;
    int ret = VarSamplesFinalize(contextPtr, &val);
    *value = sqrt(val);
    return ret;
}

void StdReset(void *contextPtr) {
    StdContext *context = (StdContext *)contextPtr;
    context->cnt = 0;
    context->sum = 0;
    context->sum_2 = 0;
}

void StdWriteContext(void *contextPtr, RedisModuleIO *io) {
    StdContext *context = (StdContext *)contextPtr;
    RedisModule_SaveDouble(io, context->sum);
    RedisModule_SaveDouble(io, context->sum_2);
    RedisModule_SaveUnsigned(io, context->cnt);
}

int StdReadContext(void *contextPtr, RedisModuleIO *io, REDISMODULE_ATTR_UNUSED int encver) {
    StdContext *context = (StdContext *)contextPtr;
    bool err = false;
    context->sum = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->sum_2 = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->cnt = LoadUnsigned_IOError(io, err, TSDB_ERROR);
    return TSDB_OK;
}

void rm_free(void *ptr) {
    free(ptr);
}

bool nonNaNValueValid(double value) {
    return !isnan(value);
}

bool nanValueValid(double value) {
    return isnan(value);
}

bool allValueValid(double value) {
    return true;
}

// time weighted avg
static AggregationClass aggWAvg = {
    .type = TS_AGG_TWA,
    .createContext = TwaCreateContext,
    .appendValue = TwaAddValue,
    .freeContext = rm_free,
    .finalize = TwaFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = TwaWriteContext,
    .readContext = TwaReadContext,
    .addBucketParams = TwaAddBucketParams,
    .addPrevBucketLastSample = TwaAddPrevBucketLastSample,
    .addNextBucketFirstSample = TwaAddNextBucketFirstSample,
    .getLastSample = TwaGetLastSample,
    .resetContext = TwaReset,
    .cloneContext = TwaCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggAvg = {
    .type = TS_AGG_AVG,
    .createContext = AvgCreateContext,
    .appendValue = AvgAddValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = AvgFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = AvgWriteContext,
    .readContext = AvgReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = AvgReset,
    .cloneContext = AvgCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggStdP = {
    .type = TS_AGG_STD_P,
    .createContext = StdCreateContext,
    .appendValue = StdAddValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = StdPopulationFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = StdWriteContext,
    .readContext = StdReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = StdReset,
    .cloneContext = StdCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggStdS = {
    .type = TS_AGG_STD_S,
    .createContext = StdCreateContext,
    .appendValue = StdAddValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = StdSamplesFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = StdWriteContext,
    .readContext = StdReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = StdReset,
    .cloneContext = StdCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggVarP = {
    .type = TS_AGG_VAR_P,
    .createContext = StdCreateContext,
    .appendValue = StdAddValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = VarPopulationFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = StdWriteContext,
    .readContext = StdReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = StdReset,
    .cloneContext = StdCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggVarS = {
    .type = TS_AGG_VAR_S,
    .createContext = StdCreateContext,
    .appendValue = StdAddValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = VarSamplesFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = StdWriteContext,
    .readContext = StdReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = StdReset,
    .cloneContext = StdCloneContext,
    .isValueValid = nonNaNValueValid,
};

void *MaxMinCreateContext(__unused bool reverse) {
    MaxMinContext *context = (MaxMinContext *)malloc(sizeof(MaxMinContext));
    context->minValue = DBL_MAX;
    context->maxValue = _DOUBLE_MIN;
    return context;
}

void *MaxMinCloneContext(void *contextPtr) {
    MaxMinContext *buf = (MaxMinContext *)malloc(sizeof(MaxMinContext));
    memcpy(buf, contextPtr, sizeof(MaxMinContext));
    return buf;
}

void MaxAppendValue(void *context, double value, __attribute__((unused)) timestamp_t ts) {
    _AssignIfGreater(&((MaxMinContext *)context)->maxValue, &value);
}

void MaxAppendValuesVec(void *__restrict__ context,
                        double *__restrict__ values,
                        size_t si,
                        size_t ei) {
    for (int i = si; i <= ei; ++i) {
        _AssignIfGreater(&((MaxMinContext *)context)->maxValue, &values[i]);
    }
}

void MinAppendValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    if (value < context->minValue) {
        context->minValue = value;
    }
}

void MaxMinAppendValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    if (value > context->maxValue) {
        context->maxValue = value;
    }
    if (value < context->minValue) {
        context->minValue = value;
    }
}

int MaxFinalize(void *contextPtr, double *value) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    *value = context->maxValue;
    return TSDB_OK;
}

int MinFinalize(void *contextPtr, double *value) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    *value = context->minValue;
    return TSDB_OK;
}

int RangeFinalize(void *contextPtr, double *value) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    *value = context->maxValue - context->minValue;
    return TSDB_OK;
}

void MaxMinReset(void *contextPtr) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    context->minValue = DBL_MAX;
    context->maxValue = _DOUBLE_MIN;
}

void MaxMinWriteContext(void *contextPtr, RedisModuleIO *io) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    RedisModule_SaveDouble(io, context->maxValue);
    RedisModule_SaveDouble(io, context->minValue);
}

int MaxMinReadContext(void *contextPtr, RedisModuleIO *io, int encver) {
    MaxMinContext *context = (MaxMinContext *)contextPtr;
    bool err = false;
    context->maxValue = LoadDouble_IOError(io, err, TSDB_ERROR);
    context->minValue = LoadDouble_IOError(io, err, TSDB_ERROR);
    if (encver < TS_ALIGNMENT_TS_VER) {
        size_t len = 1;
        char *sb = LoadStringBuffer_IOError(io, &len, err, TSDB_ERROR);
        RedisModule_Free(sb);
    }
    return TSDB_OK;
}

void SumAppendValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    context->value += value;
}

void CountAppendValue(void *contextPtr, double value, __attribute__((unused)) timestamp_t ts) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    context->value++;
}

int CountFinalize(void *contextPtr, double *val) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    *val = context->value;
    return TSDB_OK;
}

void FirstAppendValue(void *contextPtr, double value, timestamp_t ts) {
    FirstValueContext *context = (FirstValueContext *)contextPtr;
    /* Direction-independent: keep the OLDEST sample by timestamp. */
    if (context->isResetted || ts < context->ts) {
        context->isResetted = false;
        context->value = value;
        context->ts = ts;
    }
}

void LastAppendValue(void *contextPtr, double value, timestamp_t ts) {
    SingleValueContext *context = (SingleValueContext *)contextPtr;
    /* Direction-independent: keep the NEWEST sample by timestamp. `fresh_bucket` lets the first
     * sample of a new bucket always land — important for reverse mode where a newer-bucket value
     * still sits in `ts` from the previous iteration. */
    if (context->fresh_bucket || ts >= context->ts) {
        context->value = value;
        context->ts = ts;
        context->fresh_bucket = false;
    }
}

static AggregationClass aggMax = {
    .type = TS_AGG_MAX,
    .createContext = MaxMinCreateContext,
    .appendValue = MaxAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = MaxFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = MaxMinWriteContext,
    .readContext = MaxMinReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = MaxMinReset,
    .cloneContext = MaxMinCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggMin = {
    .type = TS_AGG_MIN,
    .createContext = MaxMinCreateContext,
    .appendValue = MinAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = MinFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = MaxMinWriteContext,
    .readContext = MaxMinReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = MaxMinReset,
    .cloneContext = MaxMinCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggSum = {
    .type = TS_AGG_SUM,
    .createContext = SingleValueCreateContext,
    .appendValue = SumAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = SingleValueFinalize,
    .finalizeEmpty = finalize_empty_with_ZERO,
    .writeContext = SingleValueWriteContext,
    .readContext = SingleValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = SingleValueReset,
    .cloneContext = SingleValueCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggCount = {
    .type = TS_AGG_COUNT,
    .createContext = SingleValueCreateContext,
    .appendValue = CountAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = CountFinalize,
    .finalizeEmpty = finalize_empty_with_ZERO,
    .writeContext = SingleValueWriteContext,
    .readContext = SingleValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = SingleValueReset,
    .cloneContext = SingleValueCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggFirst = {
    .type = TS_AGG_FIRST,
    .createContext = FirstValueCreateContext,
    .appendValue = FirstAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = FirstValueFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = FirstValueWriteContext,
    .readContext = FirstValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = FirstValueReset,
    .cloneContext = FirstValueCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggLast = {
    .type = TS_AGG_LAST,
    .createContext = LastValueCreateContext,
    .appendValue = LastAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = SingleValueFinalize,
    .finalizeEmpty = finalize_empty_last_value,
    .writeContext = SingleValueWriteContext,
    .readContext = SingleValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = LastValueReset,
    .cloneContext = SingleValueCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggRange = {
    .type = TS_AGG_RANGE,
    .createContext = MaxMinCreateContext,
    .appendValue = MaxMinAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = RangeFinalize,
    .finalizeEmpty = finalize_empty_with_NAN,
    .writeContext = MaxMinWriteContext,
    .readContext = MaxMinReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = MaxMinReset,
    .cloneContext = MaxMinCloneContext,
    .isValueValid = nonNaNValueValid,
};

static AggregationClass aggCountNaN = {
    .type = TS_AGG_COUNT_NAN,
    .createContext = SingleValueCreateContext,
    .appendValue = CountAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = CountFinalize,
    .finalizeEmpty = finalize_empty_with_ZERO,
    .writeContext = SingleValueWriteContext,
    .readContext = SingleValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = SingleValueReset,
    .cloneContext = SingleValueCloneContext,
    .isValueValid = nanValueValid,
};

static AggregationClass aggCountAll = {
    .type = TS_AGG_COUNT_ALL,
    .createContext = SingleValueCreateContext,
    .appendValue = CountAppendValue,
    .appendValueVec = NULL, /* determined on run time */
    .freeContext = rm_free,
    .finalize = CountFinalize,
    .finalizeEmpty = finalize_empty_with_ZERO,
    .writeContext = SingleValueWriteContext,
    .readContext = SingleValueReadContext,
    .addBucketParams = NULL,
    .addPrevBucketLastSample = NULL,
    .addNextBucketFirstSample = NULL,
    .getLastSample = NULL,
    .resetContext = SingleValueReset,
    .cloneContext = SingleValueCloneContext,
    .isValueValid = allValueValid,
};

void initGlobalCompactionFunctions() {
    const X86Features *features = getArchitectureOptimization();
    aggMax.appendValueVec = MaxAppendValuesVec;

#if defined(__x86_64__)
    if (!features) {
        return;
        /* remove this comment to enable avx512
     } else if (features->avx512f) {
            aggMax.appendValueVec = MaxAppendValuesAVX512F;
            return;
        }*/
    } else if (features->avx2) {
        aggMax.appendValueVec = MaxAppendValuesAVX2;
        return;
    }
#endif // __x86_64__
    return;
}

int StringAggTypeToEnum(const char *agg_type) {
    return StringLenAggTypeToEnum(agg_type, strlen(agg_type));
}

int RMStringLenAggTypeToEnum(RedisModuleString *aggTypeStr) {
    size_t str_len;
    const char *aggTypeCStr = RedisModule_StringPtrLen(aggTypeStr, &str_len);
    return StringLenAggTypeToEnum(aggTypeCStr, str_len);
}

int StringLenAggTypeToEnum(const char *agg_type, size_t len) {
    char agg_type_lower[len];
    for (int i = 0; i < len; i++) {
        agg_type_lower[i] = tolower(agg_type[i]);
    }

    switch (len) {
        case 3:
            if (strncmp(agg_type_lower, "min", len) == 0)
                return TS_AGG_MIN;
            if (strncmp(agg_type_lower, "max", len) == 0)
                return TS_AGG_MAX;
            if (strncmp(agg_type_lower, "sum", len) == 0)
                return TS_AGG_SUM;
            if (strncmp(agg_type_lower, "avg", len) == 0)
                return TS_AGG_AVG;
            if (strncmp(agg_type_lower, "twa", len) == 0)
                return TS_AGG_TWA;
            break;
        case 4:
            if (strncmp(agg_type_lower, "last", len) == 0)
                return TS_AGG_LAST;
            break;
        case 5:
            if (strncmp(agg_type_lower, "count", len) == 0)
                return TS_AGG_COUNT;
            if (strncmp(agg_type_lower, "range", len) == 0)
                return TS_AGG_RANGE;
            if (strncmp(agg_type_lower, "first", len) == 0)
                return TS_AGG_FIRST;
            if (strncmp(agg_type_lower, "std.p", len) == 0)
                return TS_AGG_STD_P;
            if (strncmp(agg_type_lower, "std.s", len) == 0)
                return TS_AGG_STD_S;
            if (strncmp(agg_type_lower, "var.p", len) == 0)
                return TS_AGG_VAR_P;
            if (strncmp(agg_type_lower, "var.s", len) == 0)
                return TS_AGG_VAR_S;
            break;
        case 8:
            if (strncmp(agg_type_lower, "countnan", len) == 0)
                return TS_AGG_COUNT_NAN;
            if (strncmp(agg_type_lower, "countall", len) == 0)
                return TS_AGG_COUNT_ALL;
            break;
    }

    return TS_AGG_INVALID;
}

const char *AggTypeEnumToString(TS_AGG_TYPES_T aggType) {
    switch (aggType) {
        case TS_AGG_MIN:
            return "MIN";
        case TS_AGG_MAX:
            return "MAX";
        case TS_AGG_SUM:
            return "SUM";
        case TS_AGG_AVG:
            return "AVG";
        case TS_AGG_TWA:
            return "TWA";
        case TS_AGG_STD_P:
            return "STD.P";
        case TS_AGG_STD_S:
            return "STD.S";
        case TS_AGG_VAR_P:
            return "VAR.P";
        case TS_AGG_VAR_S:
            return "VAR.S";
        case TS_AGG_COUNT:
            return "COUNT";
        case TS_AGG_FIRST:
            return "FIRST";
        case TS_AGG_LAST:
            return "LAST";
        case TS_AGG_RANGE:
            return "RANGE";
        case TS_AGG_COUNT_NAN:
            return "COUNTNAN";
        case TS_AGG_COUNT_ALL:
            return "COUNTALL";
        case TS_AGG_NONE:
        case TS_AGG_INVALID:
        case TS_AGG_TYPES_MAX:
            break;
    }
    return "Unknown";
}

const char *AggTypeEnumToStringLowerCase(TS_AGG_TYPES_T aggType) {
    switch (aggType) {
        case TS_AGG_MIN:
            return "min";
        case TS_AGG_MAX:
            return "max";
        case TS_AGG_SUM:
            return "sum";
        case TS_AGG_AVG:
            return "avg";
        case TS_AGG_TWA:
            return "twa";
        case TS_AGG_STD_P:
            return "std.p";
        case TS_AGG_STD_S:
            return "std.s";
        case TS_AGG_VAR_P:
            return "var.p";
        case TS_AGG_VAR_S:
            return "var.s";
        case TS_AGG_COUNT:
            return "count";
        case TS_AGG_FIRST:
            return "first";
        case TS_AGG_LAST:
            return "last";
        case TS_AGG_RANGE:
            return "range";
        case TS_AGG_COUNT_NAN:
            return "countnan";
        case TS_AGG_COUNT_ALL:
            return "countall";
        case TS_AGG_NONE:
        case TS_AGG_INVALID:
        case TS_AGG_TYPES_MAX:
            break;
    }
    return "unknown";
}

AggregationClass *GetAggClass(TS_AGG_TYPES_T aggType) {
    switch (aggType) {
        case TS_AGG_MIN:
            return &aggMin;
        case TS_AGG_MAX:
            return &aggMax;
        case TS_AGG_AVG:
            return &aggAvg;
        case TS_AGG_TWA:
            return &aggWAvg;
        case TS_AGG_STD_P:
            return &aggStdP;
        case TS_AGG_STD_S:
            return &aggStdS;
        case TS_AGG_VAR_P:
            return &aggVarP;
        case TS_AGG_VAR_S:
            return &aggVarS;
        case TS_AGG_SUM:
            return &aggSum;
        case TS_AGG_COUNT:
            return &aggCount;
        case TS_AGG_FIRST:
            return &aggFirst;
        case TS_AGG_LAST:
            return &aggLast;
        case TS_AGG_RANGE:
            return &aggRange;
        case TS_AGG_COUNT_NAN:
            return &aggCountNaN;
        case TS_AGG_COUNT_ALL:
            return &aggCountAll;
        case TS_AGG_NONE:
        case TS_AGG_INVALID:
        case TS_AGG_TYPES_MAX:
            break;
    }
    return NULL;
}
