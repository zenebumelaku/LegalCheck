/*
 * Copyright (c) 2006-Present, Redis Ltd.
 * All rights reserved.
 *
 * Licensed under your choice of (a) the Redis Source Available License 2.0
 * (RSALv2); or (b) the Server Side Public License v1 (SSPLv1); or (c) the
 * GNU Affero General Public License v3 (AGPLv3).
 */
#include "abstract_iterator.h"
#include "query_language.h"
#include "series_iterator.h"

#ifndef FILTER_ITERATOR_H
#define FILTER_ITERATOR_H

typedef struct SeriesFilterTSIterator
{
    AbstractIterator base;
    FilterByTSArgs ByTsArgs;
    size_t tsFilterIndex; // the index in the TS filter array in ByTsArgs
    bool reverse;
} SeriesFilterTSIterator;

SeriesFilterTSIterator *SeriesFilterTSIterator_New(AbstractIterator *input,
                                                   FilterByTSArgs ByTsArgs,
                                                   bool rev);

EnrichedChunk *SeriesFilterTSIterator_GetNextChunk(struct AbstractIterator *base);

void SeriesFilterIterator_Close(struct AbstractIterator *iterator);

typedef struct SeriesFilterValIterator
{
    AbstractIterator base;
    FilterByValueArgs byValueArgs;
} SeriesFilterValIterator;

SeriesFilterValIterator *SeriesFilterValIterator_New(AbstractIterator *input,
                                                     FilterByValueArgs byValue);

EnrichedChunk *SeriesFilterValIterator_GetNextChunk(struct AbstractIterator *base);

typedef struct AggregationIterator
{
    AbstractIterator base;
    size_t numAggregations;
    AggregationClass aggregations[TS_AGG_TYPES_MAX];
    void *aggregationContexts[TS_AGG_TYPES_MAX];
    int64_t aggregationTimeDelta;
    timestamp_t timestampAlignment;
    timestamp_t aggregationLastTimestamp;
    bool hasUnFinalizedContext;
    bool reverse;
    bool initialized;
    bool empty; // should report empty buckets
    BucketTimestamp bucketTS;
    EnrichedChunk *aux_chunk; // auxiliary chunk for containing the final bucket
    Series *series;
    api_timestamp_t startTimestamp;
    api_timestamp_t endTimestamp;
    bool hasTwa; // precomputed: any aggregation is TWA
    bool handled_empty_prefix;
    bool handled_empty_suffix;
    timestamp_t prev_ts;
    bool validSamplesInBucket; // are there any valid samples in current bucket (any aggregation)
    bool validPerAgg[TS_AGG_TYPES_MAX]; // per-aggregation validity tracking for current bucket
    // Same sample filters as the query, so neighbor lookups (edge-gap drop, LOCF seed, TWA
    // interpolation) count only kept samples: a sample removed by FILTER_BY_VALUE/FILTER_BY_TS must
    // not make an edge gap look interior. Borrowed by value from the query's RangeArgs (which
    // outlives this iterator); byTsArgs holds a pointer we do not own and must not free.
    FilterByValueArgs byValueArgs;
    FilterByTSArgs byTsArgs;
} AggregationIterator;

AggregationIterator *AggregationIterator_New(struct AbstractIterator *input,
                                             size_t numAggregations,
                                             AggregationClass **aggregations,
                                             int64_t aggregationTimeDelta,
                                             timestamp_t timestampAlignment,
                                             bool reverse,
                                             bool empty,
                                             BucketTimestamp bucketTS,
                                             Series *series,
                                             api_timestamp_t startTimestamp,
                                             api_timestamp_t endTimestamp,
                                             FilterByValueArgs byValueArgs,
                                             FilterByTSArgs byTsArgs);
EnrichedChunk *AggregationIterator_GetNextChunk(struct AbstractIterator *iter);
void AggregationIterator_Close(struct AbstractIterator *iterator);

#endif // FILTER_ITERATOR_H
