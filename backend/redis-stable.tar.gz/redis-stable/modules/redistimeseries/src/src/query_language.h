/*
 * Copyright (c) 2006-Present, Redis Ltd.
 * All rights reserved.
 *
 * Licensed under your choice of (a) the Redis Source Available License 2.0
 * (RSALv2); or (b) the Server Side Public License v1 (SSPLv1); or (c) the
 * GNU Affero General Public License v3 (AGPLv3).
 */

#include "compaction.h"
#include "config.h"
#include "generic_chunk.h"
#include "indexer.h"

#include "RedisModulesSDK/redismodule.h"
#include "rmutil/alloc.h"
#include "rmutil/strings.h"
#include "rmutil/util.h"

#ifndef REDISTIMESERIES_QUERY_LANGUAGE_H
#define REDISTIMESERIES_QUERY_LANGUAGE_H

typedef enum BucketTimestamp
{
    BucketStartTimestamp = 0,
    BucketMidTimestamp,
    BucketEndTimestamp // 2
} BucketTimestamp;

typedef struct AggregationArgs
{
    bool empty; // Should return empty buckets
    api_timestamp_t timeDelta;
    BucketTimestamp bucketTS;
    size_t numClasses;          // 0 = no aggregation
    AggregationClass **classes; // heap-allocated array of pointers, NULL when numClasses == 0
} AggregationArgs;

// GroupBy reducer args
typedef struct ReducerArgs
{
    AggregationClass *aggregationClass;
    TS_AGG_TYPES_T agg_type;
} ReducerArgs;

typedef struct FilterByValueArgs
{
    bool hasValue;
    double min;
    double max;
} FilterByValueArgs;

#define MAX_TS_VALUES_FILTER 128

typedef struct FilterByTSArgs
{
    bool hasValue;
    size_t count;
    timestamp_t values[MAX_TS_VALUES_FILTER];
} FilterByTSArgs;

typedef enum RangeAlignment
{
    DefaultAlignment,
    StartAlignment,
    EndAlignment,
    TimestampAlignment
} RangeAlignment;

typedef struct RangeArgs
{
    api_timestamp_t startTimestamp;
    api_timestamp_t endTimestamp;
    bool latest;     // get also the latest unfinalized bucket from the src series
    long long count; // AKA limit
    AggregationArgs aggregationArgs;
    FilterByValueArgs filterByValueArgs;
    FilterByTSArgs filterByTSArgs;
    RangeAlignment alignment;
    timestamp_t timestampAlignment;
    bool skipAggregation; // data is already aggregated; keep agg info for RESP3 but skip re-agg
} RangeArgs;

#define LIMIT_LABELS_SIZE 50
typedef struct MRangeArgs
{
    RangeArgs rangeArgs;
    bool withLabels;
    unsigned short numLimitLabels;
    RedisModuleString *limitLabels[LIMIT_LABELS_SIZE];
    QueryPredicateList *queryPredicates;
    const char *groupByLabel;
    ReducerArgs groupByReducerArgs;
    bool reverse;
    bool excludeEmpty;
} MRangeArgs;

typedef struct MGetArgs
{
    bool withLabels;
    unsigned short numLimitLabels;
    RedisModuleString *limitLabels[LIMIT_LABELS_SIZE];
    QueryPredicateList *queryPredicates;
    bool latest;
} MGetArgs;

typedef struct CreateCtx
{
    long long retentionTime;
    long long chunkSizeBytes;
    size_t labelsCount;
    Label *labels;
    int options;
    DuplicatePolicy duplicatePolicy;
    bool skipChunkCreation;
    long long ignoreMaxTimeDiff;
    double ignoreMaxValDiff;
} CreateCtx;

int parseLabelsFromArgs(RedisModuleString **argv,
                        int argc,
                        size_t *label_count,
                        Label **labels,
                        bool allow_null_values);

int ParseChunkSize(RedisModuleCtx *ctx,
                   RedisModuleString **argv,
                   int argc,
                   const char *arg_prefix,
                   long long *chunkSizeBytes,
                   bool *found);

int ParseDuplicatePolicy(RedisModuleCtx *ctx,
                         RedisModuleString **argv,
                         int argc,
                         const char *arg_prefix,
                         DuplicatePolicy *policy,
                         bool *found);

int parseEncodingArgs(RedisModuleCtx *ctx, RedisModuleString **argv, int argc, int *options);

int parseCreateArgs(RedisModuleCtx *ctx, RedisModuleString **argv, int argc, CreateCtx *cCtx);

int ParseAggSpec(RedisModuleCtx *ctx, const char *spec, size_t specLen, int *agg_types);

int _parseAggregationArgs(RedisModuleCtx *ctx,
                          RedisModuleString **argv,
                          int argc,
                          api_timestamp_t *time_delta,
                          int *agg_types,
                          size_t *num_agg_types,
                          bool *empty,
                          BucketTimestamp *bucketTS,
                          timestamp_t *alignmentTS);

int parseLabelQuery(RedisModuleCtx *ctx,
                    RedisModuleString **argv,
                    int argc,
                    bool *withLabels,
                    RedisModuleString **limitLabels,
                    unsigned short *limitLabelsSize);

int parseFilter(RedisModuleCtx *ctx,
                RedisModuleString **argv,
                int argc,
                int filter_location,
                int query_count,
                QueryPredicateList **out);

int parseAggregationArgs(RedisModuleCtx *ctx,
                         RedisModuleString **argv,
                         int argc,
                         AggregationArgs *out);

int parseRangeArguments(RedisModuleCtx *ctx,
                        int start_index,
                        RedisModuleString **argv,
                        int argc,
                        RangeArgs *out);

QueryPredicateList *parseLabelListFromArgs(RedisModuleCtx *ctx,
                                           RedisModuleString **argv,
                                           int start,
                                           int query_count,
                                           int *response);

int parseMRangeCommand(RedisModuleCtx *ctx, RedisModuleString **argv, int argc, MRangeArgs *out);
void MRangeArgs_Free(MRangeArgs *args);

int parseMGetCommand(RedisModuleCtx *ctx, RedisModuleString **argv, int argc, MGetArgs *out);
void MGetArgs_Free(MGetArgs *args);
bool ValidateChunkSize(RedisModuleCtx *ctx, long long chunkSizeBytes, RedisModuleString **err);
bool ValidateChunkSizeSimple(long long chunkSizeBytes);
int parseLatestArg(RedisModuleCtx *ctx, RedisModuleString **argv, int argc, bool *latest);

// Build a pass-through RangeArgs for replyResultSet after group-by reduce: no re-aggregation,
// no filters, full timestamp range. Preserves count and alignment from src.
static inline RangeArgs RangeArgs_ZeroProcessing(const RangeArgs *src) {
    RangeArgs r = *src;
    r.startTimestamp = 0;
    r.endTimestamp = UINT64_MAX;
    r.aggregationArgs.numClasses = 0;
    r.aggregationArgs.classes = NULL;
    r.aggregationArgs.timeDelta = 0;
    r.filterByTSArgs.hasValue = false;
    r.filterByValueArgs.hasValue = false;
    r.latest = false;
    return r;
}

#endif // REDISTIMESERIES_QUERY_LANGUAGE_H
